//file c di esempio: conteggio occorrenze dei token (token = lettera maiuscola/lettera minuscola/cifra) 
//con soglia per l'emissione del risultato (vengono emessi solo i token che appaiono almeno n voltee)
//ed emissione di una coppia di risultati per ognuno di essi (numero di occorrenza e length del token)

//dichiarazione header e librerie
#include "../include/mr.h"
#include <stdio.h>
#include <string.h>

//funzione mapper
int filter_doub_res_mapper(const mr_file_line_t *l, mr_emit_pair_t emit, void* emit_arg, void* user_arg){

    for(size_t i = 0; i < l->line_len; i++){

        //skip dei caratteri non alfanumerici, che non possono far parte dei token
        if(!((l->line[i] >= 'a' && l->line[i] <= 'z') || (l->line[i] >= 'A' && l->line[i] <= 'Z') || (l->line[i] >= '0' && l->line[i] <= '9'))){
            continue;
        }

        //costruzione del token 
        char c = l->line[i];
        char token[2]; 
        token[0] = c;
        token[1] = '\0';

        int one = 1;

        //check su un potenziale errore della emit
        if(emit(token, &one, sizeof(int), emit_arg) == -1){
            return -1;
        }
    }

    return 0; //funzione mapper terminata correttamente
}

//funzione reducer
int filter_doub_res_reducer(const char *token, const mr_value_t *values, size_t values_count, mr_emit_result_t emit, void *emit_arg, void *user_arg){


    //recupero della soglia da user_arg (di default è 1)
    int soglia = 1;
    if(user_arg != NULL){
        soglia = *(int*)user_arg;
    }

    int total = 0;  //result da associare al token

    for(size_t i = 0; i < values_count; i++){
        int val = *(int*)values[i].data;    //cast diretto del campo data di values (il valore 1)
        total += val;
    }

    //se il token non supera la soglia non si emette nulla
    if(total <= soglia) {
        return 0;
    }

    //check su un potenziale errore della emit del 1o result (total)
    if(emit(token, &total, sizeof(int), emit_arg) == -1){
        return -1;
    }

    int token_len = (int)strlen(token);

    //check su un potenziale errore della emit del 2o result (token_len)
    if(emit(token, &token_len, sizeof(int), emit_arg) == -1){
        return -1;
    }

    return 0; //funzione reducer terminata correttamente
}

//funzione main
int main(int argc, char **argv){
    
    if(argc != 3){
        fprintf(stderr, "Errore: devono essere passati 2 argomenti: <file di input> <file di output>\n");
        return -1;
    }

    //dichiarazione strutture
    mr_t mr;
    mr_attr_t attr;


    //soglia impostata a 2
    int soglia = 2;

    //inizializzazione di attr con check
    if(mr_attr_init(&attr) == -1){
        return -1;
    }

    //set del numero di mapper threads custom con check
    if(mr_attr_set_mapper_threads(&attr, 6) == -1){
        return -1;
    }

    //set del numero di reducer threads custom con check
    if(mr_attr_set_reducer_threads(&attr, 8) == -1){
        return -1;
    }

    //set della queue-size custom con check
    if(mr_attr_set_queue_size(&attr, 32) == -1){
        return -1;
    }

    //inizializzazione di mr con check
    if(mr_create(&mr, &attr, filter_doub_res_mapper, filter_doub_res_reducer, &soglia) == -1){
        mr_attr_destroy(&attr);
        return -1;
    }

    //avvio del map_reduce con check
    if(mr_start(mr, argv[1], argv[2]) == -1){
        mr_attr_destroy(&attr);
        mr_destroy(mr);
        return -1;
    }

    //terminato il framework e prodotto l'output, vanno liberate le strutture
    mr_attr_destroy(&attr);
    mr_destroy(mr);

    return 0;   //esempio terminato correttamente
}
