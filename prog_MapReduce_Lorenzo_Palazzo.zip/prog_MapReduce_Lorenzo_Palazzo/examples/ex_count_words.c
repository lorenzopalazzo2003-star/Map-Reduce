//file c di esempio: conteggio occorrenze dei token (token = parola alfanumerica)

//dichiarazione header e librerie
#include "../include/mr.h"
#include <stdio.h>

//macro per il controllo alfanumerico
#define IS_ALNUM(c) (((c) >= 'a' && (c) <= 'z') || ((c) >= 'A' && (c) <= 'Z') || ((c) >= '0' && (c) <= '9'))

//funzione mapper
int count_words_mapper(const mr_file_line_t *l, mr_emit_pair_t emit, void* emit_arg, void* user_arg){
    
    size_t i = 0;

    while(i < l->line_len){

        //skip dei caratteri non alfanumerici
        while(i < l->line_len && !IS_ALNUM(l->line[i])){
            i++;
        }

        //inizio di una parola alfanumerica
        size_t start = i;
        while(i < l->line_len && IS_ALNUM(l->line[i])){
            i++;
        }

        //length della parola
        size_t word_len = i - start;
        if(word_len == 0) {
            continue;
        }

        //costruzione del token
        char token[word_len + 1];

        for(size_t j = 0; j < word_len; j++){
            token[j] = l->line[start + j];
        }
        token[word_len] = '\0';

        int one = 1;
        if(emit(token, &one, sizeof(int), emit_arg) == -1){
            return -1;
        }
    }

    return 0; //mapper terminata corrrettamente

}

//funzione reducer
int count_words_reducer(const char *token, const mr_value_t *values, size_t values_count, mr_emit_result_t emit, void *emit_arg, void *user_arg){

    int total = 0;  //result da associare al token

    for(size_t i = 0; i < values_count; i++){
        int val = *(int*)values[i].data;    //cast diretto del campo data di values (il valore 1)
        total += val;
    }

    //check su un potenziale errore della emit
    if(emit(token, &total, sizeof(int), emit_arg) == -1){
        return -1;
    }

    return 0; //funzione reducer terminata correttamente
}

//funzione main
int main(int argc, char **argv){
    
    if(argc != 3){
        fprintf(stderr, "Errore: devono essere passati 2 argomenti: <file di input> <file di output>\n");
        return -1;
    }

    //dichiarazione strutture
    mr_t mr;
    mr_attr_t attr;

    //inizializzazione di attr con check
    if(mr_attr_init(&attr) == -1){
        return -1;
    }

    //set del numero di mapper threads custom con check
    if(mr_attr_set_mapper_threads(&attr, 4) == -1){
        return -1;
    }

    //set del numero di reducer threads custom con check
    if(mr_attr_set_reducer_threads(&attr, 4) == -1){
        return -1;
    }

    //set della queue-size custom con check
    if(mr_attr_set_queue_size(&attr, 32) == -1){
        return -1;
    }

    //inizializzazione di mr con check
    if(mr_create(&mr, &attr, count_words_mapper, count_words_reducer, NULL) == -1){
        mr_attr_destroy(&attr);
        return -1;
    }

    //avvio del map_reduce con check
    if(mr_start(mr, argv[1], argv[2]) == -1){
        mr_attr_destroy(&attr);
        mr_destroy(mr);
        return -1;
    }

    //terminato il framework e prodotto l'output, vanno liberate le strutture
    mr_attr_destroy(&attr);
    mr_destroy(mr);

    return 0;   //esempio terminato correttamente
}