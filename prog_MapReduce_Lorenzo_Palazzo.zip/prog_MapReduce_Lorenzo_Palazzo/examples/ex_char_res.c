//file c di esempio: per ogni carattere alfanumerico (token) emette come risultato una stringa "upper:X", dove X è la maiuscola del carattere
//disclaimer: il pretty_print_out non è compatibile con questo esempio (result non è int)

#include "../include/mr.h"
#include <stdio.h>
#include <string.h>

//funzione mapper
int char_res_mapper(const mr_file_line_t *l, mr_emit_pair_t emit, void* emit_arg, void* user_arg){

    for(size_t i = 0; i < l->line_len; i++){

        //skip dei caratteri non alfanumerici, che non possono far parte dei token
        if(!((l->line[i] >= 'a' && l->line[i] <= 'z') || (l->line[i] >= 'A' && l->line[i] <= 'Z') || (l->line[i] >= '0' && l->line[i] <= '9'))){
            continue;
        }

        //costruzione del token 
        char c = l->line[i];
        char token[2]; 
        token[0] = c;
        token[1] = '\0';

        int one = 1;

        //check su un potenziale errore della emit
        if(emit(token, &one, sizeof(int), emit_arg) == -1){
            return -1;
        }
    }

    return 0; //funzione mapper terminata correttamente
}

//funzione reducer
int char_res_reducer(const char *token, const mr_value_t *values, size_t values_count, mr_emit_result_t emit, void *emit_arg, void *user_arg){

    //costruzione della stringa risultato "upper:X"
    char result[9];   
    result[0] = 'u';
    result[1] = 'p';
    result[2] = 'p';
    result[3] = 'e';
    result[4] = 'r';
    result[5] = ':';

    //conversione in maiuscolo
    char c = token[0];
    if(c >= 'a' && c <= 'z'){
        c = c - 'a' + 'A';
    }
    result[6] = c;
    result[7] = '\0';

    //check su un potenziale errore della emit
    if(emit(token, result, strlen(result), emit_arg) == -1){
        return -1;
    }

    return 0; //funzione reducer terminata correttamente
}

//funzione main
int main(int argc, char **argv){
    
    if(argc != 3){
        fprintf(stderr, "Errore: devono essere passati 2 argomenti: <file di input> <file di output>\n");
        return -1;
    }

    //dichiarazione strutture
    mr_t mr;
    mr_attr_t attr;

    //inizializzazione di attr con check
    if(mr_attr_init(&attr) == -1){
        return -1;
    }

    //set del numero di mapper threads custom con check
    if(mr_attr_set_mapper_threads(&attr, 6) == -1){
        return -1;
    }

    //set del numero di reducer threads custom con check
    if(mr_attr_set_reducer_threads(&attr, 8) == -1){
        return -1;
    }

    //set della queue-size custom con check
    if(mr_attr_set_queue_size(&attr, 32) == -1){
        return -1;
    }

    //inizializzazione di mr con check
    if(mr_create(&mr, &attr, char_res_mapper, char_res_reducer, NULL) == -1){
        mr_attr_destroy(&attr);
        return -1;
    }

    //avvio del map_reduce con check
    if(mr_start(mr, argv[1], argv[2]) == -1){
        mr_attr_destroy(&attr);
        mr_destroy(mr);
        return -1;
    }

    //terminato il framework e prodotto l'output, vanno liberate le strutture
    mr_attr_destroy(&attr);
    mr_destroy(mr);

    return 0;   //esempio terminato correttamente
}