//file contenente le funzioni per l'inizializzazione e il setting delle strutture definite nell'header mr.h

//dichiarazione header e librerie
#include "../include/mr.h"
#include "checks.h"
#include <stdlib.h>
#include <errno.h>

//funzione statica di hash di default basata sulla dimensione del token
static size_t default_hash(const char* token, size_t token_len, void* user_arg){
    size_t mul = 3;

    if(user_arg != NULL){
        mul = *(size_t*) user_arg;
    }

    if(token_len <= 5){
        return mul*7;
    }
    else if(token_len > 5 && token_len <= 10){
        return mul*10;
    }
    else{
        return mul*13;
    }
}

//funzione di inizializzazione della struttura mr_attr
int mr_attr_init(mr_attr_t * attr){
    CHECK_RETURN(attr == NULL, ERR_INVALID_ARG, "[PRI]",  "mr_attr_init", "attr", "NULL");   //check arg con la macro

    //assegnazione valori di default
    attr->mapper_threads = 1;   //almeno un thread mapper secondo consegna
    attr->reducer_threads = 1;  //almeno un thread reducer secondo consegna
    attr->queue_size = 16;      //valore scelto arbitrariamente
    attr->log_file = "mr.log";  //in caso NULL si crea con nome mr.log
    attr->hash = default_hash;  //funzione hash di default
    attr->hash_arg = NULL;      //argomento hash di default settato a NULL

    return 0;   //struttura inizializzata correttamente
}

//funzione di pulizia della struttura mr_attr
int mr_attr_destroy(mr_attr_t * attr){
    CHECK_RETURN(attr == NULL, ERR_INVALID_ARG, "[PRI]", "mr_attr_destroy", "attr", "NULL");    //check arg con macro

    /*per ora non devo dealloc nulla, semmai dovrò inserire qui free()*/

    return 0;   //struttura pulita correttamente
}

//funzione di setting del numero di mapper threads
int mr_attr_set_mapper_threads (mr_attr_t *attr , size_t n){
    CHECK_RETURN(attr == NULL, ERR_INVALID_ARG, "[PRI]", "mr_attr_set_mapper_threads", "attr", "NULL");     //check arg con macro
    CHECK_RETURN(n == 0, ERR_INVALID_ARG, "[PRI]",  "mr_attr_set_mapper_threads", "n", "0");                //check arg con macro

    attr->mapper_threads = n;   //set del numero di threads

    return 0;   //set avvenuto correttamente
}

//funzione di setting del numero di reducer threads
int mr_attr_set_reducer_threads (mr_attr_t *attr , size_t n){
    CHECK_RETURN(attr == NULL, ERR_INVALID_ARG, "[PRI]", "mr_attr_set_reducer_threads", "attr", "NULL");    //check arg con macro
    CHECK_RETURN(n == 0, ERR_INVALID_ARG, "[PRI]", "mr_attr_set_reducer_threads", "n", "0");                //check arg con macro

    attr->reducer_threads = n;  //set del numero di threads

    return 0;   //set avvenuto correttamente
}

//funzione di setting della capacità della coda
int mr_attr_set_queue_size (mr_attr_t *attr , size_t n){
    CHECK_RETURN(attr == NULL, ERR_INVALID_ARG, "[PRI]", "mr_attr_set_queue_size", "attr", "NULL");     //check arg con macro
    CHECK_RETURN(n == 0, ERR_INVALID_ARG, "[PRI]", "mr_attr_set_queue_size", "n", "0");                 //check arg con macro

    attr->queue_size = n;   //set della capacità della coda

    return 0;   //set avvenuto correttamente
}

//funzione di setting del file di log
int mr_attr_set_log_file (mr_attr_t *attr , const char * path){
    CHECK_RETURN(attr == NULL, ERR_INVALID_ARG, "[PRI]", "mr_attr_set_log_file", "attr", "NULL");     //check arg con macro
    //nessun check su path perchè può essere NULL

    attr->log_file = path;  //set del file di log

    return 0;   //set avvenuto correttamente
}

//funzione di setting dei parametri di hashing
int mr_attr_set_hash_function (mr_attr_t *attr , mr_hash_t hash , void * hash_arg){
    CHECK_RETURN(attr == NULL, ERR_INVALID_ARG, "[PRI]", "mr_attr_set_hash_function", "attr", "NULL");     //check arg con macro
    //nessun check su hash_arg perchè può esser NULL

    if(hash == NULL){   //se il valore passato per l'hash è null viene resettata la hash function di default
        attr->hash = default_hash;
    }
    else{
        attr->hash = hash;          //set della funzione hash
    }

    attr->hash_arg = hash_arg;  //set dell'argomento

    return 0;                   //set avvenuto correttamente
}
