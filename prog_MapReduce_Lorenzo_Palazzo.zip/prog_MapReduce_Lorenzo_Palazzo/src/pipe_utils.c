//file c contenente le funzioni per la scrittura e lettura sulle pipe

//dichiarazione header e librerie
#include "pipe_utils.h"
#include <unistd.h>

//funzione di supporto per la write sulle pipe
ssize_t readn(int fd, void* buf, size_t n){
    size_t byteleft = n;    //i byte rimasti da leggere, all'inizio coincidono con il totale
    ssize_t read_res;       //risultato della read: nbyte letti, o 0 in caso di EOF, o -1 in caso di errore
    char* buf_ptr = buf;    //puntatore al buffer

    while(byteleft > 0){
        if((read_res = read(fd, buf_ptr, byteleft)) < 0){    //se occorre un problema durante la read la funzione ritorna errore
            return -1;
        }
        else if(read_res == 0){ //EOF: la pipe è stata chiusa, uscita dal ciclo
            break;
        }

        //aggiornamento puntatore e contatore
        byteleft -= read_res;
        buf_ptr += read_res;
    }
    return (n - byteleft); /*ritorna i byte letti: in caso di lettura completa byteleft = 0, quindi ritornerà n, altrimenti in caso di 
                            interruzione n - byteleft*/
}       

//funzione di supporto per la write sulle pipe
ssize_t writen(int fd, const void* buf, size_t n){
    size_t byteleft = n;        //i byte rimasti da leggere, all'inizio coincidono con il totale
    ssize_t write_res;          //risultato della write: nbyte scritti o -1 in caso di errore
    const char* buf_ptr = buf;  //puntatore al buffer

    while(byteleft > 0){
        if((write_res = write(fd, buf_ptr, byteleft)) < 0){    //se occorre un problema durante la write la funzione ritorna errore
            return -1;
        }

        //aggiornamento puntatore e contatore
        byteleft -= write_res;
        buf_ptr += write_res;
    }

    return n; //come una write normale se tutto fila liscio ritorna i byte scritti
}