//file c per la gestione del file di log

//dichiarazione header e librerie
#include "logger.h"
#include "checks.h"
#include <stdio.h>
#include <time.h>
#include <sys/time.h>
#include <sys/file.h>

static FILE *log_fp = NULL; //variabile globale puntatore del file 

int mr_log_init(const char* path){
    //check arg non necessario perchè il log__file non può mai esser NULL, è inizializzato normale e viene controllato il suo setting

    //apertura del file in modalità append per permettere a tutti i processi di scrivere le proprie righe in modo sequenziale con check
    log_fp = fopen(path, "a");
    CHECK_RETURN(log_fp == NULL, ERR_OPEN, "[PRI]", "mr_log_init", "file", path);

    return 0; //apertura avvenuta correttamente
}

void mr_log_write(const char* pre, const char* thr, const char* even, const char* msg){
    //check di sicurezza: se il log non è attivo, uscita silenziosa senza sccrivere nulla
    if (log_fp == NULL) return;

    //calcolo del tempo

    //metodo gettimeofday per ricevere un valore preciso al microsecondo
    struct timeval tv;
    gettimeofday(&tv, NULL);

    //formattazione in formato leggibile
    struct tm tm_buf;
    struct tm *tm_info = localtime_r(&tv.tv_sec, &tm_buf);
    char timestamp[32]; //buffer per "YYYY-MM-DD HH:MM:SS"
    strftime(timestamp, sizeof(timestamp), "%Y-%m-%d %H:%M:%S", tm_info);

    //lock sul file per garantire sincronizzazione
    int fd = fileno(log_fp);
    flock(fd, LOCK_EX);

    //stampa sicura
    fprintf(log_fp, "[%s.%06ld] %s [%s] [%s] %s\n", timestamp, (long)tv.tv_usec, pre, thr, even, msg);
    fflush(log_fp); 

    //rilascio della lock
    flock(fd, LOCK_UN);
}

int mr_log_destroy(){
    if(log_fp != NULL){
        //chiusura del log file con check
        int res_c = fclose(log_fp);
        log_fp = NULL;
        CHECK_RETURN(res_c == EOF, ERR_CLOSE, "[PRI]", "mr_log_destroy", "file", "log");
    }

    return 0;   //destroy avvenuta correttamente
}