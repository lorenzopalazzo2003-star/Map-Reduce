//file header contenente le funzioni per la scrittura e lettura sulle pipe

//dichiarazione librerie
#include <sys/types.h>

#ifndef PIPE_UTILS_H
#define PIPE_UTILS_H

ssize_t readn(int fd, void* buf, size_t n);
ssize_t writen(int fd, const void* buf, size_t n);

#endif