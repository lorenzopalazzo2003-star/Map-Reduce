//file c per la scrittura del filee contenente le statische globali richiesto dall'addendum

//dichiarazione header e librerie
#include "stats_writer.h"
#include "checks.h"
#include "logger.h"
#include <stdio.h>
#include <string.h>
#include <time.h>
#include <unistd.h>


double get_current_time_double(void){
    struct timespec ts;
    CHECK_GOTO(clock_gettime(CLOCK_MONOTONIC, &ts) == -1, ERR_SYSCALL, "[PRI]", "get_current_time_double", "clock_gettime", NULL, handle_fail);

    return (double)ts.tv_sec + (double)ts.tv_nsec * 1e-9;

    //branch di terminazione in caso di errore
    handle_fail:
        return -1.0;
}

int write_stats_tmp(const char *pre, const char *id_log, const mr_stats_t *stats) {

    //costruzione del path per il file temporaneo
    char path[128];
    if(strcmp(pre, "[MAP]") == 0){
        snprintf(path, sizeof(path), "mr_stats_mapper.tmp");
    } else {
        snprintf(path, sizeof(path), "mr_stats_reducer.tmp");
    }

    //apertura file in modalità di scrittura con check
    FILE *f = fopen(path, "w");
    CHECK_RETURN_LOG(f == NULL, ERR_OPEN, pre, "write_stats_tmp", "file", path, id_log, "Fallimento nell'apertura del file stats temp");
    mr_log_write(pre, id_log, "SUCCESS", "Apertura del file stats temp");

    //scrittura 
    fprintf(f, "%zu %zu %zu %zu", stats->lines_read, stats->pairs_prod, stats->distinct_tok, stats->res_prod);

    //chiusura con check
    CHECK_RETURN_LOG(fclose(f) == EOF, ERR_CLOSE, pre, "write_stats_tmp", "file", path, id_log, "Fallimento nella chiusura del file stats temp");
    mr_log_write(pre, id_log, "SUCCESS", "Chiusura del file stats temp . File scritto correttamente");

    return 0; //file scritto correttamente
}

int write_stats_file(const char *output_path, double time){

    //creazione oggetti stats per incapsulare i valori contenuti nei rispettivi file temp
    mr_stats_t map_stats;
    mr_stats_t red_stats;

    //apertura del file stats temp del mapper in modalità di lettura con check
    FILE *fm = fopen("mr_stats_mapper.tmp", "r");
    CHECK_RETURN_LOG(fm == NULL, ERR_OPEN, "[PRI]", "write_stats_file", "file", "mr_stats_mapper.tmp", "MAIN", 
        "Fallimento nell'apertura del file stats temp per la creazione del file stats globale");
    mr_log_write("[PRI]", "MAIN", "SUCCESS", "Apertura del file temp di statistiche per la creazione del file stats globale");

    //lettura e incapsulamento
    fscanf(fm, "%zu %zu %zu %zu", &map_stats.lines_read, &map_stats.pairs_prod, &map_stats.distinct_tok, &map_stats.res_prod);

    //chiusura con check
    CHECK_RETURN_LOG(fclose(fm) == EOF, ERR_CLOSE, "[PRI]", "write_stats_file", "file", "mr_stats_mapper.tmp", "MAIN", 
        "Fallimento nella chiusura del file stats temp");
    mr_log_write("[PRI]", "MAIN", "SUCCESS", "Chiusura del file temp di statistiche. Incapsulamento avvenuto correttamente");

    //apertura del file stats temp del reducer in modalità di lettura con check
    FILE *fr = fopen("mr_stats_reducer.tmp", "r");
    CHECK_RETURN_LOG(fr == NULL, ERR_OPEN, "[PRI]", "write_stats_file", "file", "mr_stats_reducer.tmp", "MAIN", 
        "Fallimento nell'apertura del file stats temp per la creazione del file stats globale");
    mr_log_write("[PRI]", "MAIN", "SUCCESS", "Apertura del file temp di statistiche per la creazione del file stats globale");

    //lettura e incapsulamento
    fscanf(fr, "%zu %zu %zu %zu", &red_stats.lines_read, &red_stats.pairs_prod, &red_stats.distinct_tok, &red_stats.res_prod);

    //chiusura con check
    CHECK_RETURN_LOG(fclose(fr) == EOF, ERR_CLOSE, "[PRI]", "write_stats_file", "file", "mr_stats_reducer.tmp", "MAIN", 
        "Fallimento nella chiusura del file stats temp");
    mr_log_write("[PRI]", "MAIN", "SUCCESS", "Chiusura del file temp di statistiche. Incapsulamento avvenuto correttamente");

    //costruzione path del file globale delle statistiche
    
    //si vuole che abbia lo stesso path del file di output, ma al posto dell'estensione .txt, l'estensione .stats
    char stats_path[8192];
    size_t len = strlen(output_path);
    int pos = -1;   //posizione del '.'

    //ciclo while a ritroso per trovare il punto
    for(int i = (int)len - 1; i >= 0; i--) {
        if (output_path[i] == '.') {
            pos = i;
            break;
        }
    }

    //definizione path dello stats file
    if(pos == -1){   // '.' non trovato, si fa semplicemente l'append
        snprintf(stats_path, sizeof(stats_path), "%s.stats", output_path);
    }
    else{
        char cut_path[8192];
        strncpy(cut_path, output_path, pos);    //copia dell'output_path per tagliarne l'estensione
        cut_path[pos] = '\0'; // si taglia l'estensione
        snprintf(stats_path, sizeof(stats_path), "%s.stats", cut_path);
    }

    //logica di scrittura del file 

    //apertura file con check
    FILE *f = fopen(stats_path, "w");
    CHECK_RETURN_LOG(f == NULL, ERR_OPEN, "[PRI]", "write_stats_file", "file", stats_path, "MAIN", 
        "Fallimento nella apertura dello stats file globale");
    mr_log_write("[PRI]", "MAIN", "SUCCESS", "Apertura del file stats globale");

    //scrittura
    fprintf(f, "MAP_REDUCE GLOBAL STATS REPORT \n");
    fprintf(f, "------------------------------ \n");
    fprintf(f, "EXECUTION TIME:         %6f sec \n", time);
    fprintf(f, "TOTAL LINES READ:       %zu \n", map_stats.lines_read);
    fprintf(f, "TOTAL PAIRS PRODUCED:   %zu \n", map_stats.pairs_prod);
    fprintf(f, "TOTAL DISTINCT TOKEN:   %zu \n", red_stats.distinct_tok);
    fprintf(f, "TOTAL RESULTS PRODUCED: %zu \n", red_stats.res_prod);

    //chiusura file con check
    CHECK_RETURN_LOG(fclose(f) == EOF, ERR_CLOSE, "[PRI]", "write_stats_file", "file", stats_path, "MAIN", 
        "Fallimento nella chiusura dello stats file globale");
    mr_log_write("[PRI]", "MAIN", "SUCCESS", "Chiusura del file stats globale. File scritto correttamente");

    //pulizia dei file temporanei
    unlink("mr_stats_mapper.tmp");
    unlink("mr_stats_reducer.tmp");

    return 0; //scrittura avvenuta correttamente
}