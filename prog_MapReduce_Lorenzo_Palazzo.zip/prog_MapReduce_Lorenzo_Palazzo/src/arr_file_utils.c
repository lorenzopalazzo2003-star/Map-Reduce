//file c contenente strutture di supporto relative agli array di file utilizzati dalla funzione principal_process_main in mr.c

//dichiarazione header e librerie
#include "arr_file_utils.h"
#include "checks.h"
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <sys/stat.h>
#include <dirent.h>

int file_array_init(file_array_t* array){

    array->size = 0;        //array inizialmente vuoto        
    array->capacity = 20;   /*valore arbitrario modificabile in base agli input con cui si ha a che fare (più file sono nella dir, più conviene 
                            aumentare questo valore)*/

    //allocazione della memoria per l'array con check
    array->filenames = (char**)malloc(sizeof(char*) * array->capacity);  
    CHECK_RETURN_LOG(array->filenames == NULL, ERR_ALLOC, "[PRI]", "file_array_init", "filename_array", NULL, "MAIN", 
        "Fallimento nell'allocazione della memoria per l'array di file in input"); 

    return 0;   //inizializzazione avvenuta correttamente
}

int file_array_insert(file_array_t* array, const char* filename){

    if(array->size == array->capacity){     //non c'è più spazio nell'array
        size_t new_cap = array->capacity * 2;  //capacità ipotetica futura (se realloc funziona) raddoppiata

        //allocazione di un'area di memoria raddoppiata per l'array con check
        char** new_arr = (char**) realloc (array->filenames, sizeof(char*) * new_cap);
        CHECK_RETURN_LOG(new_arr == NULL, ERR_ALLOC, "[PRI]", "file_array_insert", "filename_array", NULL, "MAIN", 
        "Fallimento nella riallocazione della memoria per l'insert nell'array di file in input");

        //realloc andata a buon fine
        array->capacity = new_cap;
        array->filenames = new_arr;
    }
    
    //c'è spazio nell'array (già c'era oppure è stato riallocato)

    //assegnazione del valore passato come parametro all'elemento dell'array
    size_t len = strlen(filename) + 1;
    array->filenames[array->size] = malloc(len);
    CHECK_RETURN_LOG(array->filenames[array->size] == NULL, ERR_ALLOC, "[PRI]", "file_array_insert", "filename_array", NULL, "MAIN",
        "Fallimento nell'allocazione della memoria per l'insert nell'array di file in input");
    memcpy(array->filenames[array->size], filename, len);

    array->size++;  //incremento di size 

    return 0;   //inserimento andato a buon fine
}

//funzione di supporto per comparare le stringhe
static int compare_filenames(const void* fn1, const void* fn2){
    const char* str_fn1 = *(const char**)fn1;
    const char* str_fn2 = *(const char**)fn2;
    return strcmp(str_fn1, str_fn2);
}

void file_array_sort(file_array_t* array){

    if(array->size > 1){    //se ci sono almeno 2 elementi fai l'ordinamento
        qsort(array->filenames, array->size, sizeof(char*), compare_filenames);
    }

    return;   //ordinamento completato correttamente
}

void file_array_free(file_array_t* array){

    if(array->filenames != NULL){
        for(size_t i = 0; i < array->size; i++){
            if(array->filenames[i] != NULL){
                free(array->filenames[i]);   //liberazione di ogni aree di memoria contenente una stringa duplicata con strdup
            }
        }

        free(array->filenames);     //liberazione dell'intero array
    }

    //update dei campi
    array->size = 0;
    array->capacity = 0;
    array->filenames = NULL;

    return;   //free avvenuta correttamente
}

int get_files_from_dir(const char* path, file_array_t* array){

    DIR *dir = NULL;    //dichiarazione dell'eventuale directory da aprire

    //creazione struttura per accedere ai metadati del file o directory passato in input con check
    struct stat info;
    CHECK_RETURN_LOG(stat(path, &info) == -1, ERR_SYSCALL, "[PRI]", "get_files_from_dir", "Stat per accedere ai metadati", path, "MAIN",
        "Fallimento nella creazione di stat per accedere ai metadati del path in input");

    if(S_ISREG(info.st_mode)){   //CASO BASE: il path passato come parametro è un file
        //inserimento nell'array con check se la insert fallisse
        //check silent perchè eredita l'errore dalla sottofunzione
        CHECK_RETURN_SILENT(file_array_insert(array, path) != 0);

        return 0; //inserimento avvenuto correttamente
    }
    
    if(S_ISDIR(info.st_mode)){  //CASO RICORSIVO: il path passato come parametro è una directory
        //apertura della directory con check
        dir = opendir(path);
        CHECK_RETURN_LOG(dir == NULL, ERR_OPEN, "[PRI]", "get_files_from_dir", "directory", path, "MAIN",
        "Fallimento nella apertura della directory in input");

        struct dirent* entry;   //creazione puntatore
        errno = 0;              /*errno settato a 0, perchè è l'unico modo per verificare se si sono verificati errori durante la readdir poichè
                                readdir()==NULL sia in caso di errore sia in caso di EOF*/

        while((entry = readdir(dir)) != NULL){  //ciclo fino a che la readdir trova entry nella dir (ci sono ancora file da inserire nell'array)
            //skip delle entry (.) directory stessa e (..) directory madre che, se trovate da readdir, manderebbero in tilt la ricorsione
            if(entry->d_name[0] == '.'){
                if(entry->d_name[1] == '\0' || (entry->d_name[1] == '.' && entry->d_name[2] == '\0')){
                    continue;
                }
            }

            //i d_name le entry sono tutti nomi di file o sottodirectory

            //costruzione del path relativo del file o sottodirectory
            char *next_path = malloc(4096);
            CHECK_GOTO_LOG(next_path == NULL, ERR_ALLOC, "[PRI]", "get_files_from_dir", "next_path", NULL, handle_fail, "MAIN",
                "Fallimento allocazione next_path");
            
            snprintf(next_path, 4096, "%s/%s", path, entry->d_name);

            //chiamata ricorsiva, con check : se fallisce -> jump a handle_fail 
            //check silent perchè eredita il messaggio corretto di fallimento dalla sottofunzione

            int res_gffd = get_files_from_dir(next_path, array);
            free(next_path);
            CHECK_GOTO_SILENT(res_gffd != 0, handle_fail);
        }

        //check sull'errno: se si è modificato è occorso un errore nella readdir
        CHECK_GOTO_LOG(errno != 0, ERR_SYSCALL, "[PRI]", "get_files_from_dir", "readdir", path, handle_fail, "MAIN",
        "Fallimento nella lettura della directory in input");
        
        //chiusura della directory con check
        CHECK_RETURN_LOG(closedir(dir) == -1, ERR_CLOSE, "[PRI]", "get_files_from_dir", "directory", path, "MAIN",
        "Fallimento nella chiusura della directory in input");
    }
    return 0;   //la scansione è andata a buon fine

    //branch di terminazione in caso di errore con goto
    handle_fail:
        //chiusura directory
        if(dir != NULL){
            closedir(dir);
        }
        return -1;  //la scansione non è andata a buon fine
}