//file header contenente la logica del processo reducer

#ifndef REDUCER_H 
#define REDUCER_H

//dichiarazione header e librerie
#include "mr_struct_def.h"
#include "arr_group_utils.h"
#include "stats_writer.h"
#include <threads.h>

//struct per gli argomenti da passare ai thread (che devono esser castati da void)
typedef struct {
    group_array_t *gr_arr;
    mr_t mr;
    mtx_t *mutex;
    mr_stats_t *stats;
    size_t thread_id;
} reducer_thread_args_t;

//funzione contenente la logica del processo reducer
void reducer_process_main(mr_t mr);

#endif