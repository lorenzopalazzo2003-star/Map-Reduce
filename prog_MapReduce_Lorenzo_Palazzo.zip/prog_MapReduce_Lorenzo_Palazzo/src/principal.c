//file c contenente la logica del processo principale

//dichiarazione header e librerie
#include "principal.h"
#include "../include/mr.h"
#include "mr_struct_def.h"
#include "arr_file_utils.h"
#include "pipe_utils.h"
#include "checks.h"
#include "logger.h"
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <sys/stat.h>

//funzione statica utilizzata dal processo principale che prende in input un file e forma le righe serializzate da inviare nella pipe
static int handle_single_file(const char* full_path, const char* input_path, mr_t mr){ 
    #define MAX_FILE_NAME_LEN 1024      //valore arbitrario abbastanza grande per contenere il path relativo del file_name
    #define MAX_LINE_LEN 8192           //valore arbitrario abbastanza grande per contenere una riga di testo

    //primi datI da inviare sulla pipe: dim file_name (path relativo) e file name

    const char* file_name = NULL;

    if(strcmp(full_path, input_path) == 0){ //l'input è un singolo file, ci interessa solo il nome corto e non tutto il path
        size_t i = strlen(full_path); //segnaposto sul pathname per andare a trovare l'ultimo '/' e isolare il nome corto

        while(i > 0 && full_path[i-1] != '/'){  //ciclo per trovare l'ultimo '/'
            i--;
        }

        file_name = full_path + i;  //avanza il puntatore di full_path al primo carattere dopo l'ultimo '/'
    }
    else{   //il file da inviare sulla pipe appartiene alla directory in input, ci interessa il percorso relativo
        file_name = full_path + strlen(input_path); /*avanza il puntatore di full_path per rimuovere il path della cartella in input, che è 
                                                    uguale per tutti */
        
        if(file_name[0] == '/'){    //per evitare che il path relativo parta con il carattere '/'
            file_name++;
        }
    }

    size_t file_name_len = strlen(file_name);     //dimensione del file_name, non conta il carattere di terminazione '\0'

    //resto dei dati da inviare, dim riga, riga, e numero di riga

    //apertura in modalità lettura del file avente come percorso full_path con check
    FILE* f = fopen(full_path, "r");   
    CHECK_RETURN_LOG(f == NULL, ERR_OPEN, "[PRI]", "handle_single_file", "file", full_path, "MAIN", "Fallimento apertura file in input");
    mr_log_write("[PRI]", "MAIN", "SUCCESS", "Apertura file in input");

    char line[MAX_LINE_LEN];
    unsigned long line_number = 0;
      

    while(fgets(line, MAX_LINE_LEN, f) != NULL){ //lettura di MAX_LINE_LEN carratteri fino al carattere '/n' o all'EOF

        line_number++;  //incremento del numero di riga

        size_t line_len = strlen(line); //lunghezza della riga letta (non conta il terminatore \0)
        
        //nel caso in cui la linea termini per via di '\n' e non di EOF, il carattere '\n' va rimosso
        if(line_len > 0 && line[line_len -1] == '\n'){
            line_len--;
            line[line_len] = '\0'; //carattere di terminazione che va a sovrascrivere '\n' per troncare la stringa
        }

        //logica di invio dati sulla pipe

        //da protocollo standard del progetto gli header di dimensione sono castati al tipo int con check

        CHECK_GOTO_LOG(file_name_len > MAX_FILE_NAME_LEN, ERR_INVALID_ARG, "[PRI]", "handle_single_file", "file_name_len", "fuori range", 
            handle_fail_writen, "MAIN", "Fallimento: file_name_len non valido");
        int i_file_name_len = (int) file_name_len;
        
        CHECK_GOTO_LOG(line_len > MAX_LINE_LEN, ERR_INVALID_ARG, "[PRI]", "handle_single_file", "line_len", "fuori range", handle_fail_writen, 
            "MAIN", "Fallimento: line_len non valido");
        int i_line_len = (int) line_len;

        //invio dati

        //invio dim(file_name) con check: se fallisce -> jump a handle_fail_writen
        CHECK_GOTO_LOG(writen(mr->pipe_pri_map_fd[1], &i_file_name_len, sizeof(int)) == -1, ERR_PIPE, "[PRI]",  "handle_single_file", "p-m", 
            "w(file_name_len)", handle_fail_writen, "MAIN", "Fallimento invio file_name_len");
        
        //invio file_name con check: se fallisce -> jump a handle_fail_writen 
        CHECK_GOTO_LOG(writen(mr->pipe_pri_map_fd[1], file_name, i_file_name_len) == -1, ERR_PIPE, "[PRI]",  "handle_single_file", "p-m", 
            "w(file_name)", handle_fail_writen, "MAIN", "Fallimento invio file_name");              

        //invio line_number con check: se fallisce -> jump a handle_fail_writen
        CHECK_GOTO_LOG(writen(mr->pipe_pri_map_fd[1], &line_number, sizeof(unsigned long int)) == -1, ERR_PIPE, "[PRI]",  "handle_single_file", "p-m", 
            "w(line_number)", handle_fail_writen, "MAIN", "Fallimento invio line_number"); 

        //invio dim(line) con check: se fallisce -> jump a handle_fail_writen
        CHECK_GOTO_LOG(writen(mr->pipe_pri_map_fd[1], &i_line_len, sizeof(int)) == -1, ERR_PIPE, "[PRI]", "handle_single_file", "p-m", 
            "w(line_len)", handle_fail_writen, "MAIN", "Fallimento invio line_len");
        
        //invio line con check: se fallisce -> jump a handle_fail_writen
        CHECK_GOTO_LOG(writen(mr->pipe_pri_map_fd[1], line, i_line_len) == -1, ERR_PIPE, "[PRI]", "handle_single_file", "p-m", 
            "w(line)", handle_fail_writen, "MAIN", "Fallimento invio line");
    }

    //chiusura del file inviato con check
    CHECK_RETURN_LOG(fclose(f) == EOF, ERR_CLOSE, "[PRI]", "handle_single_file", "file", full_path,  "MAIN", "Fallimento chiusura file in input");
    mr_log_write("[PRI]", "MAIN", "SUCCESS", "Chiusura file in input");

    return 0;   //l'invio dei dati del file sulla pipe è andato a buon fine

    //branch di chiusura in caso di fallimento di una writen
    handle_fail_writen:
        //nessun check sulla chiusura, tanto anche se fallisce si sta già ritornando un errore
        fclose(f);
        return -1;
}

//funzione statica adoperata dal processo principale per leggeere i dati ricevuti dal reducer e stamparli sul file di output
static int send_output(mr_t mr, const char * output_path){

    //flag necessari per gestione degli errori
    int file_open = 0;
    int token_alloc = 0;
    int result_alloc = 0;

    //apertura in modalità scrittura binaria del file di output
    FILE* f = fopen(output_path, "w+b");   
    CHECK_RETURN_LOG(f == NULL, ERR_OPEN, "[PRI]", "send_output", "file", output_path, "MAIN", "Fallimento apertura file di output");
    mr_log_write("[PRI]", "MAIN", "SUCCESS", "Apertura file di output");
    file_open = 1;  //aggiornamento del flag

    char *token = NULL;     //dichiarazione di token
    void *result = NULL;    //dichiarazione come null, se result_size = 0 rimane tale
    
    //logica di lettura dalla pipe r-p

    while(1){

        //1o dato ricevuto: token_len
        int token_len = 0; 
        ssize_t res_tl = readn(mr->pipe_red_pri_fd[0], &token_len, sizeof(int));

        if(res_tl == 0){   //EOF: si esce dal ciclo di lettura
            break;
        }

        //check se è errore di read (res_tl = -1) o read incompleta (res_tl < sizeof(int))
        CHECK_GOTO_LOG(res_tl < (ssize_t)sizeof(int), ERR_PIPE, "[PRI]", "send_output", "r-p", "r(token_len)", handle_fail, "MAIN", 
            "Fallimento nella lettura su pipe (r-p) di token_len");          
        
        //il dato è letto correttamente

        //2o dato letto: token

        //allocazione memoria per il token con check (si alloca uno spazio in più per aggiungere il terminatore '\0')
        token = malloc(token_len+1);
        CHECK_GOTO_LOG(token == NULL, ERR_ALLOC, "[PRI]", "send_output", "token", NULL, handle_fail, "MAIN",
            "Fallimento nella allocazione di memoria per il campo token");
        
        //allocazione andata a buon fine, si procede con la lettura

        token_alloc = 1; //modifica al flag di allocazione per la pulizia nella goto

        ssize_t res_tk = readn(mr->pipe_red_pri_fd[0], (void*)token, token_len);

        //check se è errore di read (res_tk = -1) o read incompleta (res_tk < sizeof(int)) o anche EOF a metà messaggio (res_tk = -0)
        CHECK_GOTO_LOG(res_tk < (ssize_t)token_len, ERR_PIPE, "[PRI]", "send_output", "r-p", "r(token)", handle_fail, "MAIN", 
            "Fallimento nella lettura su pipe (r-p) di token");
        //altrimenti lettura andata a buon fine

        //aggiunta del terminatore \0 al token
        token[token_len] = '\0';

        //3o dato ricevuto: result_size
        int result_size = 0; 
        ssize_t res_rs = readn(mr->pipe_red_pri_fd[0], &result_size, sizeof(int));

        //check se è errore di read (res_rs = -1) o read incompleta (res_rs < sizeof(int)) o anche EOF a metà messaggio (res_rs = -0)
        CHECK_GOTO_LOG(res_rs < (ssize_t)sizeof(int), ERR_PIPE, "[PRI]", "send_output", "r-p", "r(result_size)", handle_fail, "MAIN", 
            "Fallimento nella lettura su pipe (r-p) di result_size");          
        
        //il dato è letto correttamente

        //4o dato letto: result (può anche esser NULL nel caso in cui result_size sia = 0)

        if(result_size > 0){

            //allocazione memoria per il result con check
            result = malloc(result_size);
            CHECK_GOTO_LOG(result == NULL, ERR_ALLOC, "[PRI]", "send_output", "result", NULL, handle_fail, "MAIN",
                "Fallimento nella allocazione di memoria per il campo result");
        
            //allocazione andata a buon fine, si procede con la lettura

            result_alloc = 1; //modifica al flag di allocazione per la pulizia nella goto

            ssize_t res_r = readn(mr->pipe_red_pri_fd[0], (void*)result, result_size);

            //check se è errore di read (res_r = -1) o read incompleta (res_r < sizeof(int)) o anche EOF a metà messaggio (res_r = -0)
            CHECK_GOTO_LOG(res_r < (ssize_t)result_size, ERR_PIPE, "[PRI]", "send_output", "r-p", "r(result)", handle_fail, "MAIN", 
                "Fallimento nella lettura su pipe (r-p) di result");
            //altrimenti lettura andata a buon fine
        }

        //a questo punto abbiamo incapsulato correttamente i dati inviati dal reducer, si passa alla scrittura del record sul file

        /*la scrittura binaria prevede dati contigui, senza logica di separazione nè tra i dati del record nè tra i record, il programma 
        di supporto che garantiscce la leggibilità dell'output si preoccuperà di gestire tale logica*/

        CHECK_GOTO_LOG(fwrite(&token_len, sizeof(int), 1, f) != 1, ERR_SYSCALL, "[PRI]", "send_output", "fwrite", output_path, handle_fail, 
            "MAIN", "Fallimento scrittura token_len su file di output");

        CHECK_GOTO_LOG(fwrite(token, token_len, 1, f) != 1, ERR_SYSCALL, "[PRI]", "send_output", "fwrite", output_path, handle_fail, "MAIN", 
            "Fallimento scrittura token su file di output");

        CHECK_GOTO_LOG(fwrite(&result_size, sizeof(int), 1, f) != 1, ERR_SYSCALL, "[PRI]", "send_output", "fwrite", output_path, handle_fail, 
            "MAIN", "Fallimento scrittura result_size su file di output");

        if(result_size > 0){
            CHECK_GOTO_LOG(fwrite(result, result_size, 1, f) != 1, ERR_SYSCALL, "[PRI]", "send_output", "fwrite", output_path, handle_fail, "MAIN", 
                "Fallimento scrittura result su file di output");
        }
        //scrittura record ultimata, si deallocano token e result per questa iterazione
        free(token);
        token_alloc = 0;
        free(result);
        result_alloc = 0;

    }

    //chiusura del file output con check
    CHECK_RETURN_LOG(fclose(f) == EOF, ERR_CLOSE, "[PRI]", "send_output", "file", output_path,  "MAIN", "Fallimento chiusura file in di output");
    mr_log_write("[PRI]", "MAIN", "SUCCESS", "Chiusura file di output");

    return 0;   //scrittura avvenuta correttamente

    //branch di terminazione in caso di errori
    handle_fail:

        //chiusura forzata del file di output
        if(file_open == 1){
            fclose(f);
        }
        if(token_alloc == 1){
            free(token);
        }
        if(result_alloc == 1){
            free(result);
        }

        return -1;  //errore nella scrittura
}

int principal_process_main(mr_t mr, const char * input_path, const char * output_path){
    //argomenti già validati dalla start

    //logica di invio dati al mapper

    //creazione struttura per accedere ai metadati del file o directory passato in input con check
    struct stat info;
    CHECK_RETURN_LOG(stat(input_path, &info) == -1, ERR_SYSCALL, "[PRI]", "principal_process_main", "Stat", "input_path",  "MAIN", 
        "Fallimento creazione struttura stat per accedere ai metadati del path in input");

    file_array_t files;     //variabile locale della struttura contenente la lista di file nella dir in input
    int flag_files = 0;     //flag sull'inizializzazione del file (se a 1 va poi liberato con free)

    if(S_ISDIR(info.st_mode)){  //l'input_path è una directory

        //inizializzazione della struttura con check
        //check silent perchè eredita il messaggio corretto di fallimento dalla sottofunzione
        CHECK_RETURN_SILENT(file_array_init(&files));
        flag_files = 1;
        
        //chiamata a funzione che fornisce la lista di file con check: se fallisce -> jump a handle_fail
        //check silent perchè eredita il messaggio corretto di fallimento dalla sottofunzione
        CHECK_GOTO_SILENT(get_files_from_dir(input_path, &files), handle_fail);

        file_array_sort(&files);  //sort in ordine lessicografico della lista di file

        for(size_t i = 0; i < files.size; i++){    //ciclo sui file della lista

            //chiamata alla funzione che invia le righe serializzate al mapper con check: se fallisce -> jump a handle_fail
            //check silent perchè eredita il messaggio corretto di fallimento dalla sottofunzione
            CHECK_GOTO_SILENT(handle_single_file(files.filenames[i], input_path, mr), handle_fail);
        }    

    }
    else if(S_ISREG(info.st_mode)){ //l'input_path è un file regolare
        //chiamata alla funzione che invia le righe serializzate al mapper con check
        CHECK_GOTO_SILENT(handle_single_file(input_path, input_path, mr), handle_fail);
    }
    else{   //l'input path non è nè un file, nè una directory
        CHECK_GOTO_LOG(1, ERR_GENER, "[PRI]", "principal_process_main", "Formato dell'input_path non valido", NULL, handle_fail,  "MAIN", 
            "Fallimento a causa del formato del file passato in input");
    }

    //terminazione della scrittura, manda un EOF al mapper che segnala la fine dell'invio dati 
    CHECK_GOTO_LOG(close(mr->pipe_pri_map_fd[1]) == -1, ERR_SYSCALL, "[PRI]", "principal_process_main", "Chiusura fd w(pipe pri-map)", NULL, 
        handle_fail, "MAIN", "Fallimento chiusura pipe pri-map[1]");
    mr_log_write("[PRI]", "MAIN", "SUCCESS", "Completamento invio dati al mapper");

    mr->pipe_pri_map_fd[1] = -1;    //per evitare doppia chiusura eventualmente in handle_fail

    //logica di ricezione dati dal reducer

    //chiamata alla funzione di stampa sul file di output dei dati ricevuti dal reducer
    CHECK_GOTO_SILENT(send_output(mr, output_path) == -1, handle_fail);

    //msg di log 
    mr_log_write("[PRI]", "MAIN", "SUCCESS", "File di output scritto correttamente");

    //liberazione di memoria allocata per la lista di file
    if(flag_files == 1){
        file_array_free(&files);
    }

    //terminazione della lettura, chiusura del descrittore in input
    CHECK_GOTO_LOG(close(mr->pipe_red_pri_fd[0]) == -1, ERR_SYSCALL, "[PRI]", "principal_process_main", "Chiusura fd r(pipe red-pri)", NULL, 
        handle_fail, "MAIN", "Fallimento chiusura pipe red-pri[0]");

    mr->pipe_red_pri_fd[0] = -1;    //per evitare doppia chiusura eventualmente in handle_fail

    return 0;   //il processo principale è terminato con successo

    handle_fail:

        //chiusura forzata delle pipe
        if(mr->pipe_pri_map_fd[1] != -1){
            close(mr->pipe_pri_map_fd[1]);
        }
        if(mr->pipe_red_pri_fd[0] != -1){
            close (mr->pipe_red_pri_fd[0]);
        }
        //liberazione di memoria allocata per la lista di file
        if(flag_files == 1){
            file_array_free(&files);
        }

        return -1;
}
