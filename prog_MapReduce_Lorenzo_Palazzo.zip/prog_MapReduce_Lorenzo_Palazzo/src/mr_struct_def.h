//header di definizione della struct mr definita in mr.h come un handle opaco

#ifndef MR_STRUCT_DEF_H 
#define MR_STRUCT_DEF_H

//dichiarazione header e librerie
#include "../include/mr.h"
#include <sys/types.h>

struct mr{
    mr_attr_t attr;                 //attributi
    mr_mapper_t mapper;             //puntatore alla funzione mapper;
    mr_reducer_t reducer;           //puntatore alla funzione reducer;
    void *user_arg;                 //puntatore di tipo generico

    pid_t mapper_pid;               //PID del processo figlio mapper
    pid_t reducer_pid;              //PID del processo figlio reducer;

    int pipe_pri_map_fd[2];         //pipe per la comunicazione tra processo princiapale e mapper;
    int pipe_map_red_fd[2];         //pipe per la comunicazione tra mapper e reducer;
    int pipe_red_pri_fd[2];         //pipe per la comunicazione tra reducer e processo principale;
};

#endif