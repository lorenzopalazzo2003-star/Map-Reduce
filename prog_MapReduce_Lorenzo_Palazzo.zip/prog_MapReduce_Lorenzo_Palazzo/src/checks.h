//header file specifico per check sui valori

#ifndef CHECKS_H
#define CHECKS_H

//dichiarazione librerie
#include <stdio.h>
#include <errno.h>
#include <string.h>
#include <unistd.h>
#include "logger.h"
#define INC_LEN 512

//enum per identificare i diversi tipi di errore e stampare per ognuno di essi il messaggio corrispondente
typedef enum{
    ERR_INVALID_ARG,    //argomento non valido
    ERR_ALLOC,          //fallimento allocazione di memoria
    ERR_SYSCALL,        //fallimento syscall
    ERR_OPEN,           //fallimento open di un file o di una directory
    ERR_CLOSE,          //fallimento close di un file o di una directory
    ERR_PIPE,           //fallimento di un'operazione su una pipe
    ERR_SYNC_INIT,      //inizializzazione di una primitiva di sincronizzazione non riuscita
    ERR_GENER,          //errore generico
} err_t;

//funzione statica di stampa degli errori
static void print_err(err_t err, const char* pre, const char* fun, const char* info1, const char* info2){
    int errno_saved = errno; //salvataggio in locale della variabile errno settata dal fail in oggetto

    //creazione incipit comune a tutti i messaggi di errore
    char incipit[INC_LEN];
    snprintf(incipit, sizeof(incipit), "%s ERRORE: in funzione %s", pre, fun);

    //switch sul suffisso a seconda del tipo di errore
    switch(err){
        case ERR_INVALID_ARG:
            errno = EINVAL; //il check sull'argomento non avviene su una funzione che setta errno, pertanto si setta manualmente
            fprintf(stderr, "%s - L'argomento (%s) non può esser %s \n", incipit, info1, info2);
            break;
        case ERR_ALLOC:
            fprintf(stderr, "%s - Allocazione struttura (%s) fallita \n", incipit, info1);
            break;
        case ERR_SYSCALL:
            if(info2 != NULL){
                fprintf(stderr, "%s - Syscall (%s su %s) fallita: %s \n", incipit, info1, info2, strerror(errno_saved));
            }
            else{
                fprintf(stderr, "%s - Syscall (%s) fallita: %s \n", incipit, info1, strerror(errno_saved));
            }
            break;
        case ERR_OPEN:
            fprintf(stderr, "%s - Apertura di %s (%s) fallita: %s \n", incipit, info1, info2, strerror(errno_saved));
            break;
        case ERR_CLOSE:
            fprintf(stderr, "%s - Chiusura di %s (%s) fallita: %s \n", incipit, info1, info2, strerror(errno_saved));
            break;
        case ERR_PIPE:
            fprintf(stderr, "%s - Su pipe %s - Fallimento operazione (%s) \n", incipit, info1, info2);
            break;
        case ERR_SYNC_INIT:
            fprintf(stderr, "%s - Fallimento inizializzazione primitiva di sincronizzazione (%s) \n", incipit, info1);
            break;
        case ERR_GENER:
            fprintf(stderr, "%s - %s \n", incipit, info1);
            break;
        default:
            break;
    }
}

//macro effettive di controllo

//check che ritornano il valore -1

//versione standard
#define CHECK_RETURN(cond, err, pre, fun, info1, info2)\
    do{\
        if(cond){\
            print_err(err, pre, fun, info1, info2);\
            return -1;\
        }\
    } while(0)

//versione muta (non stampa nulla)
#define CHECK_RETURN_SILENT(cond)\
    do{\
        if(cond){\
            return -1;\
        }\
    } while(0)

//versione con write sul log
#define CHECK_RETURN_LOG(cond, err, pre, fun, info1, info2, thr, log_msg)\
    do{\
        if(cond){\
            print_err(err, pre, fun, info1, info2);\
            mr_log_write(pre, thr, "ERROR", log_msg);\
            return -1;\
        }\
    } while(0)

//check che fanno exit

//versione standard
#define CHECK_EXIT(cond, err, pre, fun, info1, info2)\
    do{\
        if(cond){\
            print_err(err, pre, fun, info1, info2);\
            _exit(1);\
        }\
    } while(0)

//versione muta (non stampa nulla)
#define CHECK_EXIT_SILENT(cond)\
    do{\
        if(cond){\
            _exit(1);\
        }\
    } while(0)

//versione con write sul log
#define CHECK_EXIT_LOG(cond, err, pre, fun, info1, info2, thr, log_msg)\
    do{\
        if(cond){\
            print_err(err, pre, fun, info1, info2);\
            mr_log_write(pre, thr, "ERROR", log_msg);\
            _exit(1);\
        }\
    } while(0)

//check che saltano a un branch di chiusura

//versione standard
#define CHECK_GOTO(cond, err, pre, fun, info1, info2, branch)\
    do{\
        if(cond){\
            print_err(err, pre, fun, info1, info2);\
            goto branch;\
        }\
    } while(0)

//versione muta (non stampa nulla)
#define CHECK_GOTO_SILENT(cond, branch)\
    do{\
        if(cond){\
            goto branch;\
        }\
    } while(0)

//versione con write sul log
#define CHECK_GOTO_LOG(cond, err, pre, fun, info1, info2, branch, thr, log_msg)\
    do{\
        if(cond){\
            print_err(err, pre, fun, info1, info2);\
            mr_log_write(pre, thr, "ERROR", log_msg);\
            goto branch;\
        }\
    } while(0)


#endif
