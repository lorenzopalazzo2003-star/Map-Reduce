//file header contenente strutture di supporto relative agli array di file utilizzati dalla funzione principal_process_main in mr.c

#ifndef ARR_FILE_UTILS_H
#define ARR_FILE_UTILS_H

//dichiarazione header e librerie
#include "../include/mr.h"

typedef struct{
    char** filenames;
    size_t size;
    size_t capacity;
} file_array_t;

//funzione per inizializzare l'array
int file_array_init(file_array_t* array);

//funzione per aggiungere un filename all'array
int file_array_insert(file_array_t* array, const char* filename);

//funzione per fare l'ordinamento lessicografico dell'array
void file_array_sort(file_array_t* array);

//funzione per liberare la memoria allocata per l'array
void file_array_free(file_array_t* array);

//funzione per estrarre un array di file da una directory
int get_files_from_dir(const char* path, file_array_t* array);

#endif