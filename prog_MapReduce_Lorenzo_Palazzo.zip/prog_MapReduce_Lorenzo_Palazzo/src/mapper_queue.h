//file header contenente la logica di funzionamento della coda sincronizzata interna al processo mapper

#ifndef MAPPER_QUEUE_H 
#define MAPPER_QUEUE_H

//dichiarazione header e librerie
#include "../include/mr.h"
#include <threads.h>

//struttura della coda concorrente del mapper, implementata come buffer circolare con dimensione pari alla capacità massima
typedef struct{
    mr_file_line_t **arr;   //array di puntatori a strutture mr_file_line_t
    int head;               //indice della testa dell'array
    int tail;               //indice della coda dell'array    
    int capacity;           //capacità massima della coda
    int num_elem;           //numero di elementi attualmente in coda
    int flag_open;          //flag: 1 se la coda è aperta, 0 se è chiusa (dopo ricezione EOF)

    //concorrenza
    mtx_t mutex;        //variabile di mutua esclusione per l'interazione con la coda
    cnd_t empty;        //condizione bloccante per il consumatore: coda vuota
    cnd_t full;         //condizione bloccante per il produttore: coda piena
} map_queue_t;

//funzione per inizializzare la coda
int map_queue_init(map_queue_t* queue, int cap, const char* id_log);

//funzione per inserire un elemento nella coda
void map_queue_push(map_queue_t* queue, mr_file_line_t *elem);

//funzione per estrarre un elemento nella coda (estrazione FIFO)
mr_file_line_t* map_queue_pop(map_queue_t* queue);

//funzione per chiudere la coda
void map_queue_close(map_queue_t* queue);

//funzione per distruggere la coda
void map_queue_destroy(map_queue_t* queue);

#endif