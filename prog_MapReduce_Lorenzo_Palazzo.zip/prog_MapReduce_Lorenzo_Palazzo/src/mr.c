//file principale del framework

//dichiarazione header e librerie
#include "../include/mr.h"
#include "mr_struct_def.h"
#include "principal.h"
#include "mapper.h"
#include "reducer.h"
#include "stats_writer.h"
#include "logger.h"
#include "checks.h"
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>


//funzione che forma la struttura mr e la inizializza
int mr_create (mr_t *mr, const mr_attr_t *attr, mr_mapper_t mapper, mr_reducer_t reducer, void * user_arg){
    CHECK_RETURN(mr == NULL, ERR_INVALID_ARG, "[PRI]", "mr_create", "mr", "NULL");              //check arg con la macro
    CHECK_RETURN(attr == NULL, ERR_INVALID_ARG, "[PRI]", "mr_create", "attr", "NULL");          //check arg con la macro
    CHECK_RETURN(mapper == NULL, ERR_INVALID_ARG, "[PRI]", "mr_create", "mapper", "NULL");      //check arg con la macro
    CHECK_RETURN(reducer == NULL, ERR_INVALID_ARG, "[PRI]", "mr_create", "reducer", "NULL");    //check arg con la macro
    //nessun check su user_arg perchè può essere NULL

    //allocazione della memoria per mr con check
    struct mr *new_mr = malloc(sizeof(struct mr));
    CHECK_RETURN(new_mr == NULL, ERR_ALLOC, "[PRI]", "mr_create", "new_mr", NULL);

    //inizializzazione campi della mr creata
    new_mr->attr = *attr;
    new_mr->mapper = mapper;
    new_mr->reducer = reducer;
    new_mr->user_arg = user_arg;

    new_mr->mapper_pid = -1;    //Pid inizializzato a -1
    new_mr->reducer_pid = -1;   //Pid inizializzato a -1

    new_mr->pipe_pri_map_fd[0] = -1;    //File descr della pipe p-m inizializzato a -1
    new_mr->pipe_pri_map_fd[1] = -1;    //File descr della pipe p-m inizializzato a -1

    new_mr->pipe_map_red_fd[0] = -1;    //File descr della pipe m-r inizializzato a -1
    new_mr->pipe_map_red_fd[1] = -1;    //File descr della pipe m-r inizializzato a -1

    new_mr->pipe_red_pri_fd[0] = -1;    //File descr della pipe r-p inizializzato a -1
    new_mr->pipe_red_pri_fd[1] = -1;    //File descr della pipe r-p inizializzato a -1

    //binding del puntatore passato come argomento a quello della nuova struttura
    *mr = new_mr;

    return 0;   //create avvenuta correttamente
}

/*funzione che configura e avvia la pipeline, stabilendo i collegamenti tra le pipe, creando i processi mapper e reducer, e lanciandoli assieme al
processo principale*/
int mr_start (mr_t mr, const char * input_path, const char * output_path){

    CHECK_RETURN(mr == NULL, ERR_INVALID_ARG, "[PRI]", "mr_start", "mr", "NULL");                       //check arg con la macro
    CHECK_RETURN(input_path == NULL, ERR_INVALID_ARG, "[PRI]", "mr_start", "input_path", "NULL");       //check arg con la macro
    CHECK_RETURN(output_path == NULL, ERR_INVALID_ARG, "[PRI]", "mr_start", "output_path", "NULL");     //check arg con la macro

    //calcolo timestamp di avvio esecuzione
    double start_time = get_current_time_double();
    CHECK_RETURN_SILENT(start_time == -1.0);

    //apertura del file di log con check
    int res_mrli = mr_log_init(mr->attr.log_file);
    CHECK_RETURN_SILENT(res_mrli == -1);

    //primo messaggio del log
    mr_log_write("[PRI]", "MAIN", "SUCCESS", "Avvio framework");

    //apertura delle pipe con check
    CHECK_RETURN_LOG(pipe(mr->pipe_pri_map_fd) == -1, ERR_SYSCALL, "[PRI]", "mr_start", "Apertura pipe pri-map", NULL, "MAIN", 
        "Fallimento apertura pipe pri-map");
    mr_log_write("[PRI]", "MAIN", "SUCCESS", "Apertura pipe pri-map");  //altrimenti msg di successo sul log

    CHECK_RETURN_LOG(pipe(mr->pipe_map_red_fd) == -1, ERR_SYSCALL, "[PRI]", "mr_start", "Apertura pipe map-red", NULL, "MAIN", 
        "Fallimento apertura pipe map-red");
    mr_log_write("[PRI]", "MAIN", "SUCCESS", "Apertura pipe map-red");  //altrimenti msg di successo sul log

    CHECK_RETURN_LOG(pipe(mr->pipe_red_pri_fd) == -1, ERR_SYSCALL, "[PRI]", "mr_start", "Apertura pipe red-pri", NULL, "MAIN", 
        "Fallimento apertura pipe red-pri");
    mr_log_write("[PRI]", "MAIN", "SUCCESS", "Apertura pipe red-pri");  //altrimenti msg di successo sul log

    //fork per creare il processo mapper a partire dal principale con check: se fallisce -> jump a handle_fail_fork
    mr->mapper_pid = fork();

    CHECK_GOTO_LOG(mr->mapper_pid == -1, ERR_SYSCALL, "[PRI]", "mr_start", "Fork del processo mapper", NULL, handle_fail_fork, "MAIN", 
        "Fallimento fork del processo mapper");
    mr_log_write("[PRI]", "MAIN", "SUCCESS", "Creazione processo mapper");  //altrimenti msg di successo sul log

    if(mr->mapper_pid == 0){     //cosa fa il processo figlio mapper

        //creazione della stringa PID per il log per il mapper
        char map_pid_str[32];
        snprintf(map_pid_str, sizeof(map_pid_str), "P:%d", (int)getpid()); //P quando l'id si riferisce al processo, T se si riferisce al thread

        // Collegamento dello stdin con il lato in lettura della pipe processo principale-mapper
        CHECK_EXIT_LOG(dup2(mr->pipe_pri_map_fd[0], 0) == -1, ERR_SYSCALL, "[MAP]", "mr_start", "Dup2", "r(pipe pri-map) - stdin", map_pid_str, 
            "Fallimento dup2 stdin (pipe pri-map)");

        // Collegamento dello stdout con il lato in scrittura della pipe mapper-reducer
        CHECK_EXIT_LOG(dup2(mr->pipe_map_red_fd[1], 1) == -1, ERR_SYSCALL, "[MAP]", "mr_start", "Dup2", "w(pipe map-red) - stdout", map_pid_str, 
            "Fallimento dup2 stdout (pipe map-red)");

        // Chiusura dei descrittori non necessari
        CHECK_EXIT_LOG(close(mr->pipe_pri_map_fd[0]) == -1, ERR_SYSCALL, "[MAP]", "mr_start", "Chiusura fd r(pipe pri-map)", NULL, map_pid_str, 
            "Fallimento chiusura pipe pri-map[0]");
        CHECK_EXIT_LOG(close(mr->pipe_pri_map_fd[1]) == -1, ERR_SYSCALL, "[MAP]", "mr_start", "Chiusura fd w(pipe pri-map)", NULL, map_pid_str, 
            "Fallimento chiusura pipe pri-map[1]");
        CHECK_EXIT_LOG(close(mr->pipe_map_red_fd[0]) == -1, ERR_SYSCALL, "[MAP]", "mr_start", "Chiusura fd r(pipe map-red)", NULL, map_pid_str, 
            "Fallimento chiusura pipe map-red[0]");
        CHECK_EXIT_LOG(close(mr->pipe_map_red_fd[1]) == -1, ERR_SYSCALL, "[MAP]", "mr_start", "Chiusura fd w(pipe map-red)", NULL, map_pid_str, 
            "Fallimento chiusura pipe map-red[1]");
        CHECK_EXIT_LOG(close(mr->pipe_red_pri_fd[0]) == -1, ERR_SYSCALL, "[MAP]", "mr_start", "Chiusura fd r(pipe red-pri)", NULL, map_pid_str, 
            "Fallimento chiusura pipe red-pri[0]");
        CHECK_EXIT_LOG(close(mr->pipe_red_pri_fd[1]) == -1, ERR_SYSCALL, "[MAP]", "mr_start", "Chiusura fd w(pipe red-pri)", NULL, map_pid_str, 
            "Fallimento chiusura pipe red-pri[1]");

        mr_log_write("[MAP]", map_pid_str, "SUCCESS", "Descrittori Mapper configurati correttamente");

        mapper_process_main(mr); //lancio della funzione figlia

    }

    //fork per creare il processo reducer a partire dal principale con check: se fallisce -> jump a handle_fail_fork
    mr->reducer_pid = fork();
    CHECK_GOTO_LOG(mr->reducer_pid == -1, ERR_SYSCALL, "[PRI]", "mr_start", "Fork del processo reducer", NULL, handle_fail_fork, "MAIN", 
        "Fallimento fork Reducer");
    mr_log_write("[PRI]", "MAIN", "SUCCESS", "Creazione processo reducer");

    if(mr->reducer_pid == 0){       //cosa fa il processo figlio reducer

        //creazione della stringa PID per il log per il reducer
        char red_pid_str[32];
        snprintf(red_pid_str, sizeof(red_pid_str), "P:%d", (int)getpid());

        // Collegamento stdin (pipe m-r)
        CHECK_EXIT_LOG(dup2(mr->pipe_map_red_fd[0], 0) == -1, ERR_SYSCALL, "[RED]", "mr_start", "Dup2", "r(pipe map-red) - stdin", red_pid_str, 
            "Fallimento dup2 stdin (pipe map-red)");
    
        // Collegamento stdout (pipe r-p)
        CHECK_EXIT_LOG(dup2(mr->pipe_red_pri_fd[1], 1) == -1, ERR_SYSCALL, "[RED]", "mr_start", "Dup2", "w(pipe red-pri) - stdout", red_pid_str, 
            "Fallimento dup2 stdout (pipe red-pri)");

        // Chiusura dei descrittori non necessari
        CHECK_EXIT_LOG(close(mr->pipe_pri_map_fd[0]) == -1, ERR_SYSCALL, "[RED]", "mr_start", "Chiusura fd r(pipe pri-map)", NULL, red_pid_str, 
            "Fallimento chiusura pipe pri-map[0]");
        CHECK_EXIT_LOG(close(mr->pipe_pri_map_fd[1]) == -1, ERR_SYSCALL, "[RED]", "mr_start", "Chiusura fd w(pipe pri-map)", NULL, red_pid_str, 
            "Fallimento chiusura pipe pri-map[1]");
        CHECK_EXIT_LOG(close(mr->pipe_map_red_fd[0]) == -1, ERR_SYSCALL, "[RED]", "mr_start", "Chiusura fd r(pipe map-red)", NULL, red_pid_str, 
            "Fallimento chiusura pipe map-red[0]");
        CHECK_EXIT_LOG(close(mr->pipe_map_red_fd[1]) == -1, ERR_SYSCALL, "[RED]", "mr_start", "Chiusura fd w(pipe map-red)", NULL, red_pid_str, 
            "Fallimento chiusura pipe map-red[1]");
        CHECK_EXIT_LOG(close(mr->pipe_red_pri_fd[0]) == -1, ERR_SYSCALL, "[RED]", "mr_start", "Chiusura fd r(pipe red-pri)", NULL, red_pid_str, 
            "Fallimento chiusura pipe red-pri[0]");
        CHECK_EXIT_LOG(close(mr->pipe_red_pri_fd[1]) == -1, ERR_SYSCALL, "[RED]", "mr_start", "Chiusura fd w(pipe red-pri)", NULL, red_pid_str, 
            "Fallimento chiusura pipe red-pri[1]");

        mr_log_write("[RED]", red_pid_str, "SUCCESS", "Descrittori Reducer configurati correttamente");
    
        reducer_process_main(mr);   // Lancio della funzione figlia
    }

    //funzionamento del processo padre

    // Chiusura dei descrittori non necessari nel processo padre
    CHECK_RETURN_LOG(close(mr->pipe_pri_map_fd[0]) == -1, ERR_SYSCALL, "[PRI]", "mr_start", "Chiusura fd r(pipe pri-map)", NULL, "MAIN", 
        "Fallimento chiusura pipe pri-map[0]");
    CHECK_RETURN_LOG(close(mr->pipe_map_red_fd[0]) == -1, ERR_SYSCALL, "[PRI]", "mr_start", "Chiusura fd r(pipe map-red)", NULL, "MAIN", 
        "Fallimento chiusura pipe map-red[0]");
    CHECK_RETURN_LOG(close(mr->pipe_map_red_fd[1]) == -1, ERR_SYSCALL, "[PRI]", "mr_start", "Chiusura fd w(pipe map-red)", NULL, "MAIN", 
        "Fallimento chiusura pipe map-red[1]");
    CHECK_RETURN_LOG(close(mr->pipe_red_pri_fd[1]) == -1, ERR_SYSCALL, "[PRI]", "mr_start", "Chiusura fd w(pipe red-pri)", NULL, "MAIN", 
        "Fallimento chiusura pipe red-pri[1]");
    mr_log_write("[PRI]", "MAIN", "SUCCESS", "Descrittori Principal configurati correttamente");

    //lancio del processo principale con check: se fallisce -> jump a handle_fail_princ
    //check silent perchè eredita il messaggio corretto di fallimento dalla sottofunzione
    CHECK_GOTO_SILENT(principal_process_main(mr, input_path, output_path) < 0, handle_fail_princ);

    // Sincronizzazione processi figli con check
    int mapper_status, reducer_status;

    CHECK_RETURN_LOG(waitpid(mr->mapper_pid, &mapper_status, 0) == -1, ERR_SYSCALL, "[PRI]", "mr_start", "Waitpid", "processo mapper", "MAIN", 
        "Fallimento waitpid mapper");
    CHECK_RETURN_LOG(waitpid(mr->reducer_pid, &reducer_status, 0) == -1, ERR_SYSCALL, "[PRI]", "mr_start", "Waitpid", "processo reducer", "MAIN", 
        "Fallimento waitpid reducer");

    //check sullo stato di uscita del processo figlio mapper: se è diverso da zero -> ha fatto _exit(1), quindi errore
    CHECK_RETURN_SILENT(WEXITSTATUS(mapper_status) != 0);

    //check sullo stato di uscita del processo figlio reducer: se è diverso da zero -> ha fatto _exit(1), quindi errore
    CHECK_RETURN_SILENT(WEXITSTATUS(reducer_status) != 0);

    //altrimenti i processi figli sono terminati correttamente
    mr_log_write("[PRI]", "MAIN", "SUCCESS", "Figli sincronizzati correttamente");

    //calcolo del tempo di esecuzione
    double finish_time = get_current_time_double();
    CHECK_RETURN_SILENT(finish_time == -1.0);

    double elapsed_time = finish_time - start_time;

    //stampa del file contenente le statistiche globali con check
    int res_wsf = write_stats_file(output_path, elapsed_time);
    CHECK_RETURN_SILENT(res_wsf == -1);

    //msg finale sul log
    mr_log_write("[PRI]", "MAIN", "SUCCESS", "Processo principale terminato correttamente");

    //chiusura file di log con check
    int res_mrld = mr_log_destroy();
    CHECK_RETURN_SILENT(res_mrld == -1);    

    return 0; // la start è terminata correttamente

    //branch di chiusura in caso di fallimento di una delle 2 fork
    handle_fail_fork:
        //nessun check sulle chiusure e sulle waitpid, tanto anche se falliscono si sta già ritornando un errore

        //chiusura forzata dei fd rimasti aperti
        close(mr->pipe_pri_map_fd[0]);
        close(mr->pipe_pri_map_fd[1]);
        close(mr->pipe_map_red_fd[0]);
        close(mr->pipe_map_red_fd[1]);
        close(mr->pipe_red_pri_fd[0]);
        close(mr->pipe_red_pri_fd[1]);

        //se il fail avviene sulla fork del reducer, è necessario attendere il processo mapper
        if(mr->mapper_pid > 0){
            waitpid(mr->mapper_pid, NULL, 0);
        }

        //chiusura file di log
        mr_log_destroy();

        return -1;

    //branch di chiusura in caso di fallimento del processo principale
    handle_fail_princ:
        //nessun check sulle chiusure e sulle waitpid, tanto anche se falliscono si sta già ritornando un errore
        
        //sincronizzazione
        waitpid(mr->mapper_pid, NULL, 0);
        waitpid(mr->reducer_pid, NULL, 0);

        //chiusura file di log
        mr_log_destroy();

        return -1;   //l'intera start ritorna errore
}

//funzione per ripulire la memoria dalle strutture allocate nella create
int mr_destroy (mr_t mr){
    CHECK_RETURN(mr == NULL, ERR_INVALID_ARG, "[PRI]", "mr_destroy", "mr", "NULL");     //check arg con la macro

    //liberazione della memoria allocata nella create
    free(mr);

    return 0;   //pulizia avvenuta correttamente
}

