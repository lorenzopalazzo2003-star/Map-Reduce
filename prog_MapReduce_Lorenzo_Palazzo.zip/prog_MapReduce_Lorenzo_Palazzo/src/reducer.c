//file c contenente la logica del processo reducer

//dichiarazione header e librerie
#include "../include/mr.h"
#include "arr_group_utils.h"
#include "pipe_utils.h"
#include "checks.h"
#include "logger.h"
#include "reducer.h"
#include "stats_writer.h"
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <threads.h>
#include <sys/syscall.h>

//funzione statica che definisce la logica del thread lettore dalla pipe m-r
static int reducer_reader_main(void *arg){
    //creazione della stringa TID per il log
    pid_t tid = syscall(SYS_gettid);
    char r_read_tid_str[32];
    snprintf(r_read_tid_str, sizeof(r_read_tid_str), "T:%d", (int)tid);

    //cast
    reducer_thread_args_t *args = (reducer_thread_args_t *)arg;
    group_array_t *gr_arr = args->gr_arr;
    mr_stats_t *stats = args->stats;

    //msg di avvio su log
    mr_log_write("[RED]", r_read_tid_str, "SUCCESS", "Avvio del thread lettore dalla pipe");

    //dichiarazione struttura value e token e group che eventualmente dovranno essere allocate
    char *token = NULL;
    void *value = NULL;
    group_t group;  //gruppo eventualmente inizializzato nel caso di prima visualizzazione di un token

    //flag per le deallocazioni in caso di errori
    int token_alloc = 0;
    int value_alloc = 0;
    int group_alloc = 0;

    while(1){

        //lettura dalla pipe

        //1o dato letto: token_len

        int token_len = 0; 
        ssize_t res_tl = readn(0, &token_len, sizeof(int));

        if(res_tl == 0){   //EOF: si esce dal ciclo di lettura
            break;
        }

        //check se è errore di read (res_tl = -1) o read incompleta (res_tl < sizeof(int))
        CHECK_RETURN_LOG(res_tl < (ssize_t)sizeof(int), ERR_PIPE, "[RED]", "reducer_reader_main", "m-r", "r(token_len)", r_read_tid_str, 
            "Fallimento nella lettura su pipe (m-r) di token_len");          
        
        //il dato è letto correttamente

        //2o dato letto: token

        //allocazione memoria per il token con check (si alloca uno spazio in più per aggiungere il terminatore '\0')
        token = malloc(token_len+1);
        CHECK_RETURN_LOG(token == NULL, ERR_ALLOC, "[RED]", "reducer_reader_main", "token", NULL, r_read_tid_str,
            "Fallimento nella allocazione di memoria per il campo token");
        
        //allocazione andata a buon fine, si procede con la lettura

        token_alloc = 1; //modifica al flag di allocazione per la pulizia nella goto

        ssize_t res_tk = readn(0, (void*)token, token_len);

        //check se è errore di read (res_tk = -1) o read incompleta (res_tk < sizeof(int)) o anche EOF a metà messaggio (res_tk = -0)
        CHECK_GOTO_LOG(res_tk < (ssize_t)token_len, ERR_PIPE, "[RED]", "reducer_reader_main", "m-r", "r(token)", handle_fail, r_read_tid_str, 
            "Fallimento nella lettura su pipe (m-r) di token");
        //altrimenti lettura andata a buon fine

        //aggiunta del terminatore \0 al token
        token[token_len] = '\0';

        //3o dato letto: value_size

        int value_size = 0;
        ssize_t res_vs = readn(0, &value_size, sizeof(int));

        //check se è errore di read (res_vs = -1) o read incompleta (res_vs < sizeof(int)) o anche EOF a metà messaggio (res_vs = -0)
        CHECK_GOTO_LOG(res_vs < (ssize_t)sizeof(int), ERR_PIPE, "[RED]", "reducer_reader_main", "m-r", "r(value_size)", handle_fail, r_read_tid_str, 
            "Fallimento nella lettura su pipe (m-r) di value_size");    

        //il dato è letto correttamente

        //4o dato letto: value

        //allocazione memoria per il value con check
        value = malloc(value_size);
        CHECK_GOTO_LOG(value == NULL, ERR_ALLOC, "[RED]", "reducer_reader_main", "value", NULL, handle_fail, r_read_tid_str,
            "Fallimento nella allocazione di memoria per il campo value");
        
        //allocazione andata a buon fine, si procede con la lettura

        value_alloc = 1; //modifica al flag di allocazione per la pulizia nella goto

        ssize_t res_v = readn(0, value, value_size);

        //check se è errore di read (res_v = -1) o read incompleta (res_v < sizeof(int)) o anche EOF a metà messaggio (res_v = -0)
        CHECK_GOTO_LOG(res_v < (ssize_t)value_size, ERR_PIPE, "[RED]", "reducer_reader_main", "m-r", "r(value)", handle_fail, r_read_tid_str, 
            "Fallimento nella lettura su pipe (m-r) di value");
        //altrimenti lettura andata a buon fine

        //logica di inserimento nell'array di groups

        //risultato della find
        int index = gr_arr_find(gr_arr, token);

        if(index < 0){   //caso: token mai apparso in precedenza

            //si alloca la struttura group (dichiarata all'inizio)con check
            int res_gi = gr_init(&group, token, token_len, r_read_tid_str);
            CHECK_GOTO_SILENT(res_gi == -1, handle_fail);

            group_alloc = 1; //modifica al flag di allocazione per la pulizia nella goto

            //si costruisce la struttura value da inserire nell'array del group alla posizione [0]
            mr_value_t val_to_put; 
            val_to_put.data = value;
            val_to_put.size = (size_t) value_size;

            //inserimento nell'array del gruppo con check
            int res_gav = (gr_add_value(&group, &val_to_put, r_read_tid_str));
            CHECK_GOTO_SILENT(res_gav == -1, handle_fail);
            value_alloc = 0; //controllo del value passato al gruppo, non si dealloca più singolarmente

            //si inserisce il nuovo gruppo nell'array con check
            int res_gains = gr_arr_insert(gr_arr, &group, r_read_tid_str);
            CHECK_GOTO_SILENT(res_gains == -1, handle_fail);
            token_alloc = 0;    //controllo del token passato al gruppo, non si dealloca più singolarmente
            group_alloc = 0;    //controllo del gruppo passato all'array, non si dealloca più singolarmente 

            //nuovo token distinto trovato, si aggiiorna il contatore
            stats->distinct_tok++;

        }
        else{   //caso: token già apparso in precedenza

            //si costruisce la struttura value da inserire nell'array
            mr_value_t val_to_put; 
            val_to_put.data = value;
            val_to_put.size = (size_t) value_size;

            //inserimento nell'array del gruppo con check
            int res_gav = (gr_add_value(&gr_arr->groups[index], &val_to_put, r_read_tid_str));
            CHECK_GOTO_SILENT(res_gav == -1, handle_fail);
            value_alloc = 0; //controllo del value passato al gruppo, non si dealloca più singolarmente

            //liberazione del campo token la cui gestione è sempre di proprietà del reader
            free(token);
            token_alloc = 0;
        }

        //reset
        token = NULL;
        value = NULL;
        token_alloc = 0;
        value_alloc = 0;
        group_alloc = 0;
    }

    return 0;   //lettura avvenuta correttamente

    //branch di terminazione in caso di errori
    handle_fail:
        //deallocazione strutture
        if(value_alloc == 1){
            free(value);
        }
        if(token_alloc == 1){
            free(token);
        }
        if(group_alloc == 1){
            gr_destroy(&group);
        }

        return -1;  //errore nella lettura

}

//funzione usata dal reducer per scrivere i risultati sulla pipe M-R
int emit_result(const char *token, const void *result, size_t result_size, void * emit_arg){
    #define MAX_TOKEN_ER_LEN 2048   //valore arbitrario abbastanza grande per contenere il token
    #define MAX_RESULT_SIZE 4096    //valore arbitrario abbastanza grande per contenere i byte di result

    //creazione della stringa TID per il log
    pid_t tid = syscall(SYS_gettid);
    char em_res_tid_str[32];
    snprintf(em_res_tid_str, sizeof(em_res_tid_str), "T:%d", (int)tid);

    //cast
    reducer_thread_args_t *args = (reducer_thread_args_t *)emit_arg;
    mtx_t *write_mutex = args->mutex;
    mr_stats_t *stats = args->stats;

    //check sul token
    CHECK_RETURN_LOG(token == NULL || token[0] == '\0', ERR_INVALID_ARG, "[RED]", "emit_result", "token", "NULL o vuoto", em_res_tid_str, 
        "Fallimento emit result: Token passato non Valido");
    
    //cast a int delle dimensioni con check 
    int i_token_len = (int) strlen (token);
    CHECK_RETURN_LOG(i_token_len == 0 || i_token_len > MAX_TOKEN_ER_LEN, ERR_INVALID_ARG, "[RED]", "emit_result", "token_len", "fuori range", 
        em_res_tid_str, "Fallimento emit result: token_len non Valido");

    CHECK_RETURN_LOG(result_size > MAX_RESULT_SIZE, ERR_INVALID_ARG, "[RED]", "emit_result", "result_size", "fuori range", em_res_tid_str, 
        "Fallimento emit result: result_size passato non Valido");
    int i_result_size = (int) result_size;

    //acquisizione della lock sulla mutex per la scrittura sincronizzata sulla pipe
    mtx_lock(write_mutex);

    //invio dati

    //invio dim(token) per l'header con check
    CHECK_GOTO_LOG(writen(1, &i_token_len, sizeof(int)) == -1, ERR_PIPE, "[RED]",  "emit_result", "r-p", "w(token_len)", handle_fail, 
        em_res_tid_str, "Fallimento invio token_len");

    //invio token con check
    CHECK_GOTO_LOG(writen(1, token, i_token_len) == -1, ERR_PIPE, "[RED]",  "emit_result", "r-p", "w(token)", handle_fail, em_res_tid_str, 
        "Fallimento invio token");
    
    //invio dim(result) per l'header con check
    CHECK_GOTO_LOG(writen(1, &i_result_size, sizeof(int)) == -1, ERR_PIPE, "[RED]",  "emit_result", "r-p", "w(result_size)", handle_fail, 
        em_res_tid_str, "Fallimento invio result_size");

    //invio result con check
    CHECK_GOTO_LOG(writen(1, result, i_result_size) == -1, ERR_PIPE, "[RED]",  "emit_result", "r-p", "w(result)", handle_fail, em_res_tid_str, 
        "Fallimento invio result");

    //invio result terminato correttamente, si può aggiornare il contatore
    stats->res_prod++;

    //rilascio della lock
    mtx_unlock(write_mutex);

    return 0;   //scrittura risultato effettuata correttamente
    
    //branch di terminazione in caso di errori
    handle_fail:
        //rilascio della lock
        mtx_unlock(write_mutex);

        return -1;   //fallimento in scrittura risultato 
}

//funzione statica che definisce la logica dei thread worker del reducer che elaborano i dati presenti sul group array
static int reducer_worker_main(void *arg){

    //creazione della stringa TID per il log
    pid_t tid = syscall(SYS_gettid);
    char r_work_tid_str[32];
    snprintf(r_work_tid_str, sizeof(r_work_tid_str), "T:%d", (int)tid);

    //cast
    reducer_thread_args_t *args = (reducer_thread_args_t *)arg;
    group_array_t *gr_arr = args->gr_arr;
    mr_t mr = args->mr;
    size_t thread_id = args->thread_id;

    //msg di avvio su log
    mr_log_write("[RED]", r_work_tid_str, "SUCCESS", "Avvio di un thread worker");

    //iterazione sul group array
    for(size_t i=0; i < gr_arr->size; i++){

        //calcolo del valore della funzione hash
        size_t hash_res = mr->attr.hash(gr_arr->groups[i].token, gr_arr->groups[i].token_len, mr->attr.hash_arg);

        //calcolo dell'id del thread corrispondente all'hash
        size_t exp_thread_id = hash_res % (mr->attr.reducer_threads);

        //se i due valori matchano allora è questo il worker che si deve occupare di chiamare la reducer sul gruppo
        if(exp_thread_id == thread_id){

            /*passaggio alla funzione reducer definita dall'utente con check (in caso di errore non mi aspetto che l'utente abbia implementato
            i check tipici del framework, di conseguenza l'errore viene trasmesso qui e non al livello inferiore (niente check silent)*/
            int res_red = mr->reducer(gr_arr->groups[i].token, gr_arr->groups[i].values, gr_arr->groups[i].size, emit_result, args, 
                mr->user_arg);
            CHECK_RETURN_LOG(res_red == -1, ERR_GENER, "[RED]", "reducer_worker_main", "Errore generico nella reducer", NULL, r_work_tid_str, 
                "Fallimento nella funzione reducer");
                
        }
    }

    return 0;   //invio dati da parte del thread avvenuto correttamente
}

void reducer_process_main(mr_t mr){
    
    //creazione della stringa PID per il log per il reducer
    char red_pid_str[32];
    snprintf(red_pid_str, sizeof(red_pid_str), "P:%d", (int)getpid());

    //flag per i fallimenti
    int flag_write_mutex_init = 0;  //variabile per la deallocazione della mutex in caso di errore
    int flag_reader = 0;            //per capire se vada atteso o meno nella handle_fail
    int workers_to_join = 0;        //count per sapere quanti ne vanno attesi in caso di fail 
    int next_to_join = 0;           //indice per sapere il prossimo su cui far la join in caso di fail
    int reader_res = 0;             //per catturare l'errore del reader
    int worker_res = 0;             //per catturare l'errore del worker
    int workers_alloc = 0;          //per l'eventuale free dell'array workers
    int thread_args_alloc = 0;      //per l'eventuale free dell'array thread_args
    int in_close = 0;               //per capire se è già stato chiuso o meno lo stdin (pulizia formale)
    int out_close = 0;              //per capire se è già stato chiuso o meno lo stdout (pulizia formale)

    //inizializzazione del group array con check
    group_array_t gr_arr;
    int res_gai = gr_arr_init(&gr_arr, red_pid_str);
    CHECK_EXIT_SILENT(res_gai == -1); //viene stampato il messaggio di errore registrato dalla funzione chiamata
    
    //variabile di mutex da passare ai worker per la corretta sincronizzazione delle scritture in output sulla pipe
    mtx_t write_mutex;

    //inizializzazione mutex con check e aggiornamento del flag in caso di success
    CHECK_GOTO_LOG(mtx_init(&write_mutex, mtx_plain) != thrd_success, ERR_SYNC_INIT, "[RED]", "reducer_process_main", "write_mutex [mtx]", NULL, 
        handle_fail, red_pid_str, "Fallimento nell'inizializzazione della write_mutex [mtx] per la scrittura sincronizzata sulla pipe R-P");
    flag_write_mutex_init = 1;

    //inizializzazione struttura stats
    mr_stats_t r_stats;
    r_stats.lines_read = 0;
    r_stats.pairs_prod = 0;
    r_stats.distinct_tok = 0;
    r_stats.res_prod = 0;

    //inizializzazione struttura args da passare aI thread 
    reducer_thread_args_t args;
    args.gr_arr = &gr_arr;
    args.mr = mr;
    args.mutex = &write_mutex;
    args.stats = &r_stats;

    //creazione del thread lettore dalla pipe, ossia colui che costruisce il group array
    thrd_t reader;
    CHECK_GOTO_LOG(thrd_create(&reader, reducer_reader_main, &args) != thrd_success, ERR_SYSCALL, "[RED]", "reducer_process_main", 
        "Create del thread lettore dalla pipe", NULL, handle_fail, red_pid_str, "Fallimento nella create del thread lettore dalla pipe");
    
    flag_reader = 1; 

    //attesa del completamento della lettura dalla pipe M-R (scrittura del group array) con check
    thrd_join(reader, &reader_res);
    flag_reader = 0;
    CHECK_GOTO_SILENT(reader_res != 0, handle_fail); //riporta l'errore catturato nella funzione reader

    //termine della lettura
    mr_log_write("[RED]", red_pid_str, "SUCCESS", "Terminazione lettura dati ricevuti dal mapper");
    close(0);
    in_close = 1;

    //arrivati a questo punto si ha a disposizione il group array definitivo, si può partire con la logica di scrittura verso il principal
    
    //ordinamento lessicografico dell'array
    gr_arr_sort(&gr_arr);

    //creazione dei thread worker, ossia coloro che elaborano i gruppi, producono i risultati e li inviano al principal
    int n_worker = (int)mr->attr.reducer_threads;    
       
    thrd_t *workers = malloc(n_worker * sizeof(thrd_t));
    CHECK_GOTO_LOG(workers == NULL, ERR_ALLOC, "[RED]", "reader_process_main", "workers", NULL, handle_fail, red_pid_str,
        "Fallimento allocazione memoria per l'array workers");                 
    workers_alloc = 1;                 
    
    //creazione di un'array di args di modo da passare ad ogni thread una struttura esclusiva, evitando race conditions
    reducer_thread_args_t *thread_args = malloc(n_worker * sizeof(reducer_thread_args_t));
    CHECK_GOTO_LOG(thread_args == NULL, ERR_ALLOC, "[RED]", "reducer_process_main", "thread_args", NULL, handle_fail, red_pid_str,
        "Fallimento allocazione memoria per l'array thread_args");
    thread_args_alloc = 1;

    //ciclo della create
    for(int i = 0; i < n_worker ; i++){
        thread_args[i] = args;
        thread_args[i].thread_id = (size_t) i;
        CHECK_GOTO_LOG(thrd_create(&workers[i], reducer_worker_main, &thread_args[i]) != thrd_success, ERR_SYSCALL, "[RED]", "reducer_process_main", 
            "Create di un thread worker", NULL, handle_fail, red_pid_str, "Fallimento nella create di un thread worker");
        workers_to_join++;
    }

    //attesa del completamento della scrittura sulla pipe R-P (scrittura dei risultati) con check
    for(int i = 0; i < n_worker ; i++){
        thrd_join(workers[i], &worker_res);
        next_to_join++;
        CHECK_GOTO_SILENT(worker_res != 0, handle_fail); //riporta l'errore catturato nella funzione worker
    }

    //termine della scrittura
    mr_log_write("[RED]", red_pid_str, "SUCCESS", "Terminazione scrittura dati verso il principal");
    close(1);
    out_close = 1;

    //scrittura dello stats file temporaneo del reducer
    write_stats_tmp("[RED]", red_pid_str, &r_stats);

    //msg sul log del numero di token distinti e risultati prodotti
    char end_line[256];
    snprintf(end_line, sizeof(end_line), "Terminazione processo reducer. Token distinti: %zu, Risultati prodotti, %zu", r_stats.distinct_tok, 
        r_stats.res_prod);

    mr_log_write("[RED]", red_pid_str, "SUCCESS", end_line);

    //liberazione array thread_args
    free(thread_args); 
    thread_args_alloc = 0;

    //liberazione array workers
    free(workers);
    workers_alloc = 0;

    //distruzione mutex
    mtx_destroy(&write_mutex);

    //deallocazione array di groups
    gr_arr_destroy(&gr_arr);

    _exit(0);   //processo mapper terminato correttamente

    //branch di terminazione in caso di errori
    handle_fail:
        //join dei thread rimasti sospesi
        if(flag_reader == 1){
            thrd_join(reader, NULL);
        }
        for(int i = next_to_join; i < workers_to_join; i++){
            thrd_join(workers[i], NULL);
        }
        
        //liberazione array thread_args
        if(thread_args_alloc == 1){
            free(thread_args);
        }

        //liberazione array workers
        if(workers_alloc == 1){
            free(workers);
        }

        //distruzione mutex
        if(flag_write_mutex_init == 1){
            mtx_destroy(&write_mutex);
        }

        //deallocazione array di groups
        gr_arr_destroy(&gr_arr);

        //chiusura stdin
        if(in_close == 0){
            close(0);
        }

        //chiusura stdout
        if(out_close == 0){
            close(1);
        }

        _exit(1);   //errore nel processo reducer
}