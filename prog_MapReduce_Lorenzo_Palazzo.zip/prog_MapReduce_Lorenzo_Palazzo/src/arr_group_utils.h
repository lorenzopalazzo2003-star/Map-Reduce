//file header contenente la logica del processo reducer

#ifndef ARR_GROUP_UTILS_H 
#define ARR_GROUP_UTILS_H 

//dichiarazione header e librerie
#include "mr_struct_def.h"

//struct per il gruppo associato al token
typedef struct{
    char *token; 
    size_t token_len;
    mr_value_t *values;
    size_t size; 
    size_t capacity;
} group_t;

//struct per l'array di gruppi
typedef struct{
    group_t *groups;
    size_t size; 
    size_t capacity;
} group_array_t;

//funzioni per group

//funzione che inizializza il gruppo singolo
int gr_init(group_t *group, char *token, size_t token_len, const char *id_log);

//funzione che aggiunge un nuovo valore nell'array di valori associato al gruppo (quando il token era già apparso in precedenza)
int gr_add_value(group_t *group, mr_value_t *value, const char *id_log);

//funzione che dealloca il gruppo
void gr_destroy(group_t *group);

//funzioni per group array

//funzione che inizializza l'array di gruppi
int gr_arr_init(group_array_t* gr_arr, const char* id_log);

//funzione che inserisce un nuovo gruppo nell'array (quando il token non era già apparso in precedenza)
int gr_arr_insert(group_array_t* gr_arr, group_t* group, const char* id_log);

//funzione che ricerca un token nell'array di groups: se lo trova ritorna l'indice, altrimenti -1
int gr_arr_find(group_array_t* gr_arr, const char *token);

//funzione che ordina l'array in ordine lessicografico (sulla base del campo token)
void gr_arr_sort(group_array_t* gr_arr);

//funzione che dealloca l'array
void gr_arr_destroy(group_array_t* gr_arr);

#endif