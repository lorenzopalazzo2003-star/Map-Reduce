//file c contenente la logica di funzionamento della coda sincronizzata interna al processo mapper

//dichiarazione header e librerie
#include "mapper_queue.h"
#include "checks.h"
#include <stdlib.h>
#include <stdio.h>

int map_queue_init(map_queue_t* queue, int cap, const char* id_log){
    //flag per capire quali variabili di sincronizzazione siano state inizializzate con successo
    int flag_mutex_init = 0;
    int flag_empty_init = 0;
    int flag_full_init = 0;

    //inizializzazione buffer
    
    queue->arr = NULL; //inizializzazione precauzionale a NULL per evitare bug in caso di fallimento della malloc

    //allocazione memoria per il buffer con check, in caso di errore jump a handle_fail
    queue->arr = (mr_file_line_t**) malloc (cap*sizeof(mr_file_line_t*));
    CHECK_GOTO_LOG((queue->arr == NULL), ERR_ALLOC, "[MAP]", "map_queue_init", "buffer di map_queue", NULL, handle_fail, id_log, 
        "Fallimento nell'allocazione della memoria per il buffer della mapper_queue");

    //inizializzazione deI campi che non necessitano allocazioni di memoria
    queue->head = 0;
    queue->tail = 0;
    queue->capacity = cap;
    queue->num_elem = 0;
    queue->flag_open = 1;
    
    //inizializzazione variabili di sincronizzazione

    //inizializzazione mutex con check e aggiornamento del flag in caso di successo, in caso di errore jump a _handle_fail
    CHECK_GOTO_LOG(mtx_init(&queue->mutex, mtx_plain) != thrd_success, ERR_SYNC_INIT, "[MAP]", "map_queue_init", "mtx [mutex]", NULL, handle_fail,
        id_log, "Fallimento nell'inizializzazione della mutex(mtx) della mapper_queue");
    flag_mutex_init = 1;

    //inizializzazione empty con check e aggiornamento del flag in caso di successo, in caso di errore jump a _handle_fail
    CHECK_GOTO_LOG(cnd_init(&queue->empty) != thrd_success, ERR_SYNC_INIT, "[MAP]", "map_queue_init", "cnd [empty]", NULL, handle_fail, id_log, 
        "Fallimento nell'inizializzazione della cnd(empty) della mapper_queue");
    flag_empty_init = 1;

    //inizializzazione full con check e aggiornamento del flag in caso di successo, in caso di errore jump a _handle_fail
    CHECK_GOTO_LOG(cnd_init(&queue->full) != thrd_success, ERR_SYNC_INIT, "[MAP]", "map_queue_init", "cnd [full]", NULL, handle_fail, id_log, 
        "Fallimento nell'inizializzazione della cnd(full) della mapper_queue");
    flag_full_init = 1;


    return 0;   //se non siamo caduti in un salto (goto) a queue_init_handle_fail, l'init è avvenuta correttamente

    //branch di terminazione in caso di errore con goto
    handle_fail:
        //dealloc array se necessaria
        if(queue->arr != NULL){
            free(queue->arr);
            queue->arr = NULL;
        }

        //destroy delle strutture 

        if(flag_mutex_init == 1){
            mtx_destroy(&queue->mutex);
        }

        if(flag_empty_init == 1){
            cnd_destroy(&queue->empty);
        }

        if(flag_full_init == 1){
            cnd_destroy(&queue->full);
        }

        return -1;  //l'inizializzazione è fallita

}

void map_queue_push (map_queue_t* queue, mr_file_line_t *elem){
    //il produttore acquisisce la lock sulla mutex
    mtx_lock(&queue->mutex);

    //se il buffer è pieno il produttore rilascia la lock e si mette in attesa che un consumatore faccia una pop e liberi dello spazio
    while(queue->num_elem == queue->capacity){
        cnd_wait(&queue->full, &queue->mutex);
    }

    //produttore ha atteso abbastanza, oppure ha avuto subito spazio dove scrivere, e inserisce la nuova line
    queue->arr[queue->tail] = elem;
    queue->tail = (queue->tail + 1) % queue->capacity;  //aggiornamento della tail fatto in questo modo per rendere il buffer circolare
    queue->num_elem++;

    //produttore ha terminato il suo lavoro, sveglia un eventuale consumatore bloccato sulla empty
    cnd_signal(&queue->empty);

    mtx_unlock(&queue->mutex);  //rilascia la lock
}

mr_file_line_t* map_queue_pop(map_queue_t* queue){
    //il consumatore acquisisce la lock sulla mutex
    mtx_lock(&queue->mutex);

    //se il buffer è vuoto (e coda attiva) il consumatore rilascia la lock e si mette in attesa che un produttore faccia una push e riempa il buffer
    while(queue->num_elem == 0 && queue->flag_open == 1){
        cnd_wait(&queue->empty, &queue->mutex);
    }

    //condizione di terminazione la coda è chiusa (qquindi non ci si scrive più) e vuota (quindi tutti gli elementi sono stati processati)
    if(queue->num_elem == 0 && queue->flag_open == 0){
        mtx_unlock(&queue->mutex);
        return NULL;
    }

    //consumatore ha atteso abbastanza, oppure ha avuto subito elementi da leggere, ed estrae la line in testa
    mr_file_line_t* ret_elem = queue->arr[queue->head];
    queue->head = (queue->head +1) % queue->capacity; //aggiornamento della head fatto in questo modo per rendere il buffer circolare
    queue->num_elem--;

    //consumatore ha terminato il suo lavoro, sveglia un eventuale produttore bloccato sulla full
    cnd_signal(&queue->full);

    mtx_unlock(&queue->mutex);  //rilascia la lock

    return ret_elem; //ritorna l'elemento estratto
}

void map_queue_close(map_queue_t* queue){
    //acquisisce la lock sulla mutex
    mtx_lock(&queue->mutex);

    //chiude la coda modificando il flag
    queue->flag_open = 0;

    /*fa una broadcast al fine di svegliare eventuali thread rimasti in attesa sulla empty, affinchè possano consumare tuti gli ultimi elementi 
    rimasti nella coda*/
    cnd_broadcast(&queue->empty);

    mtx_unlock(&queue->mutex);  //rilascia la lock
}

void map_queue_destroy(map_queue_t* queue){
    //liberazione della memoria dell'array
    free(queue->arr);

    //destroy della variabili di sincronizzazione
    mtx_destroy(&queue->mutex);
    cnd_destroy(&queue->empty);
    cnd_destroy(&queue->full);
}