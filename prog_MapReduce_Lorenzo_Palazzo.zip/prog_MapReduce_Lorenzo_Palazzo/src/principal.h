//file header contenente la logica del processo principale

#ifndef PRINCIPAL_H 
#define PRINCIPAL_H

//dichiarazione header e librerie
#include "mr_struct_def.h"

//funzione contenente la logica del processo principale
int principal_process_main(mr_t mr, const char * input_path, const char * output_path);

#endif