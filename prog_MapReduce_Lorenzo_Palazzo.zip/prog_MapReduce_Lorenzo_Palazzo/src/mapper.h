//file header contenente la logica del processo mapper

#ifndef MAPPER_H 
#define MAPPER_H

//dichiarazione header e librerie
#include "mr_struct_def.h"
#include "mapper_queue.h"
#include "stats_writer.h"
#include <threads.h>

//struct per gli argomenti da passare ai thread (che devono esser castati da void)
typedef struct {
    map_queue_t *queue;
    mr_t mr;
    mtx_t *mutex;
    mr_stats_t *stats;
} mapper_thread_args_t;

//funzione contenente la logica del processo mapper
void mapper_process_main(mr_t mr);

#endif