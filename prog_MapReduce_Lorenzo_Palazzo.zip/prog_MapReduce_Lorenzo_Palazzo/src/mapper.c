//file c contenente la logica del processo mapper

//dichiarazione header e librerie
#include "../include/mr.h"
#include "mapper_queue.h"
#include "pipe_utils.h"
#include "checks.h"
#include "logger.h"
#include "mapper.h"
#include "stats_writer.h"
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <threads.h>
#include <sys/syscall.h>

//funzione statica che definisce la logica del thread produttore sulla coda del mapper
static int mapper_reader_main(void* arg){

    //creazione della stringa TID per il log
    pid_t tid = syscall(SYS_gettid);
    char m_read_tid_str[32];
    snprintf(m_read_tid_str, sizeof(m_read_tid_str), "T:%d", (int)tid);

    //cast
    mapper_thread_args_t *args = (mapper_thread_args_t *)arg;
    map_queue_t *queue = args->queue;
    mr_t mr = args->mr;
    mr_stats_t *stats = args->stats;

    //msg di avvio su log
    mr_log_write("[MAP]", m_read_tid_str, "SUCCESS", "Avvio del thread lettore dalla pipe");

    //dichiarazione struttura file_line eventualmente da allocare
    mr_file_line_t *l = NULL;

    //flag per le deallocazioni in caso di errori
    int file_name_alloc = 0;
    int line_alloc = 0;

    while(1){

        //lettura dalla pipe

        //1o dato letto: file_name_len

        int file_name_len = 0; 
        ssize_t res_fnl = readn(0, &file_name_len, sizeof(int));

        if(res_fnl == 0){   //EOF: si esce dal ciclo di lettura
            break;
        }

        //check se è errore di read (res_fnl = -1) o read incompleta (res_fnl < sizeof(int))
        CHECK_RETURN_LOG(res_fnl < (ssize_t)sizeof(int), ERR_PIPE, "[MAP]", "mapper_reader_main", "p-m", "r(file_name_len)", m_read_tid_str, 
            "Fallimento nella lettura su pipe (p-m) di file_name_len");          
        
        //il dato è letto correttamente

        //si alloca la struttura mr_file_line_t con check
        l = malloc(sizeof(mr_file_line_t));
        CHECK_RETURN_LOG(l == NULL, ERR_ALLOC, "[MAP]", "mapper_reader_main", "l", NULL, m_read_tid_str, 
            "Fallimento nella allocazione della struttura mr_file_line_t");
        
        l->file_name_len = (size_t) file_name_len;   //assegnazione del campo con casting a size_t

        //inizializzazione a null dei campi puntatore per ripulirli da garbage
        l->file_name = NULL;
        l->line = NULL;

        //2o dato letto: file_name

        //si allocano esattamente file_name_len bytes per la riga con check 
        l->file_name = malloc(file_name_len);
        CHECK_GOTO_LOG(l->file_name == NULL, ERR_ALLOC, "[MAP]", "mapper_reader_main", "l->file_name", NULL, handle_fail, m_read_tid_str, 
            "Fallimento nella allocazione di memoria per il campo file_name");
        
        //allocazione andata a buon fine, si procede con la lettura

        file_name_alloc = 1; //modifica al flag di allocazione per la pulizia nella goto

        ssize_t res_fn = readn(0, (void*)l->file_name, file_name_len);

        //check se è errore di read (res_fn = -1) o read incompleta (res_fn < sizeof(int)) o anche EOF a metà messaggio (res_fn = -0)
        CHECK_GOTO_LOG(res_fn < (ssize_t)file_name_len, ERR_PIPE, "[MAP]", "mapper_reader_main", "p-m", "r(file_name)", handle_fail, m_read_tid_str, 
            "Fallimento nella lettura su pipe (p-m) di file_name");
        //altrimenti lettura e assegnamento campo andati a buon fine
        
        //3o dato letto: line_number
        
        ssize_t res_ln = readn(0, &l->line_number, sizeof(unsigned long int));

        //check se è errore di read (res_ln = -1) o read incompleta (res_ln < sizeof(int)) o anche EOF a metà messaggio (res_ln = -0)
        CHECK_GOTO_LOG(res_ln < (ssize_t)sizeof(unsigned long int), ERR_PIPE, "[MAP]", "mapper_reader_main", "p-m", "r(line_number)", handle_fail,
            m_read_tid_str, "Fallimento nella lettura su pipe (p-m) di line_num");
        //altrimenti lettura e assegnamento campo andati a buon fine

        //4o dato letto: line_len

        int line_len = 0; 
        ssize_t res_ll = readn(0, &line_len, sizeof(int));

        //check se è errore di read (res_ll = -1) o read incompleta (res_ll < sizeof(int)) o anche EOF a metà messaggio (res_ll = -0)
        CHECK_GOTO_LOG(res_ll < (ssize_t)sizeof(int), ERR_PIPE, "[MAP]", "mapper_reader_main", "p-m", "r(line_len)", handle_fail, m_read_tid_str, 
            "Fallimento nella lettura su pipe (p-m) di line_len");
        //altrimenti lettura e assegnamento campo andati a buon fine

        l->line_len = (size_t) line_len;   //assegnazione del campo con casting a size_t

        //5o dato letto: line

        //si allocano esattamente file_name_len bytes per la riga con check 

        
        if(line_len > 0){    //in caso di riga vuota si evita di allocare memporia per il campo e lo si mantiene a NULL
            l->line = malloc(line_len);
            CHECK_GOTO_LOG(l->line == NULL, ERR_ALLOC, "[MAP]", "mapper_reader_main", "l->line", NULL, handle_fail, m_read_tid_str, 
            "Fallimento nella allocazione di memoria per il campo line");

            //allocazione andata a buon fine, si procede con la lettura

            line_alloc = 1; //modifica al flag di allocazione per la pulizia nella goto
        
            ssize_t res_l = readn(0, (void*)l->line, line_len);

            //check se è errore di read (res_l = -1) o read incompleta (res_l < sizeof(int)) o anche EOF a metà messaggio (res_l = -0)
            CHECK_GOTO_LOG(res_l < (ssize_t)line_len, ERR_PIPE, "[MAP]", "mapper_reader_main", "p-m", "r(line)", handle_fail, m_read_tid_str, 
                "Fallimento nella lettura su pipe (p-m) di line");
            //altrimenti lettura e assegnamento campo andati a buon fine
        }

        //lettura andata a buon fine, si può aumentare il contatore e inserire la linea sulla mapper_queue
        stats->lines_read++;
        map_queue_push(queue, l);

        //reset
        l = NULL;
        file_name_alloc = 0;
        line_alloc = 0;
    }

    //msg di terminazione su log
    mr_log_write("[MAP]", m_read_tid_str, "SUCCESS", "Terminazione lettura pipe (p-m)");

    //principal chiude la pipe, non arriveranno più righe, si chiude la mapper_queue
    map_queue_close(queue);
    return 0;

    //branch di terminazione in caso di errori
    handle_fail:
        //deallocazione strutture
        if(file_name_alloc == 1){
            free((void*)l->file_name);
        }
        if(line_alloc == 1){
            free((void*)l->line);
        }
        free(l);

        //chiusura della mapper_queue
        map_queue_close(queue);

        return -1;
}

//funzione usata dal mapper per scrivere le coppie sulla pipe M-R
int emit_pair(const char *token, const void *value, size_t value_size, void *emit_arg){
    #define MAX_TOKEN_EP_LEN 2048   //valore arbitrario abbastanza grande per contenere il token
    #define MAX_VALUE_SIZE 4096     //valore arbitrario abbastanza grande per contenere i byte di value

    //creazione della stringa TID per il log
    pid_t tid = syscall(SYS_gettid);
    char em_pa_tid_str[32];
    snprintf(em_pa_tid_str, sizeof(em_pa_tid_str), "T:%d", (int)tid);

    //cast
    mapper_thread_args_t *args = (mapper_thread_args_t *)emit_arg;
    mtx_t *write_mutex = args->mutex;
    mr_stats_t *stats = args->stats;

    //check sul token
    CHECK_RETURN_LOG(token == NULL || token[0] == '\0', ERR_INVALID_ARG, "[MAP]", "emit_pair", "token", "NULL o vuoto", em_pa_tid_str, 
        "Fallimento emit pair: Token passato non Valido");
    
    //cast a int delle dimensioni con check 
    int i_token_len = (int) strlen (token);
    CHECK_RETURN_LOG(i_token_len == 0 || i_token_len > MAX_TOKEN_EP_LEN, ERR_INVALID_ARG, "[MAP]", "emit_pair", "token_len", "fuori range", 
        em_pa_tid_str, "Fallimento emit pair: token_len non Valido");

    CHECK_RETURN_LOG(value_size == 0 || value_size > MAX_VALUE_SIZE, ERR_INVALID_ARG, "[MAP]", "emit_pair", "value_size", "fuori range", 
        em_pa_tid_str, "Fallimento emit pair: value_size passato non Valido");
    int i_value_size = (int) value_size;

    //acquisizione della lock sulla mutex per la scrittura sincronizzata sulla pipe
    mtx_lock(write_mutex);

    //invio dati

    //invio dim(token) per l'header con check
    CHECK_GOTO_LOG(writen(1, &i_token_len, sizeof(int)) == -1, ERR_PIPE, "[MAP]",  "emit_pair", "m-r", "w(token_len)", handle_fail, 
        em_pa_tid_str, "Fallimento invio token_len");

    //invio token con check
    CHECK_GOTO_LOG(writen(1, token, i_token_len) == -1, ERR_PIPE, "[MAP]",  "emit_pair", "m-r", "w(token)", handle_fail, em_pa_tid_str, 
        "Fallimento invio token");
    
    //invio dim(value) per l'header con check
    CHECK_GOTO_LOG(writen(1, &i_value_size, sizeof(int)) == -1, ERR_PIPE, "[MAP]",  "emit_pair", "m-r", "w(value_size)", handle_fail, 
        em_pa_tid_str, "Fallimento invio value_size");

    //invio value con check
    CHECK_GOTO_LOG(writen(1, value, i_value_size) == -1, ERR_PIPE, "[MAP]",  "emit_pair", "m-r", "w(value)", handle_fail, em_pa_tid_str, 
        "Fallimento invio value");

    //invio coppia terminato correttamente, si può aggiornare il contatore
    stats->pairs_prod++;

    //rilascio della lock
    mtx_unlock(write_mutex);

    return 0;   //scrittura coppia effettuata correttamente
    
    //branch di terminazione in caso di errori
    handle_fail:
        //rilascio della lock
        mtx_unlock(write_mutex);

        return -1;   //fallimento in scrittura coppia 
}

//funzione statica che definisce la logica dei thread consumatori sulla coda del mapper
static int mapper_worker_main(void* arg){
    //creazione della stringa TID per il log
    pid_t tid = syscall(SYS_gettid);
    char m_work_tid_str[32];
    snprintf(m_work_tid_str, sizeof(m_work_tid_str), "T:%d", (int)tid);

    //cast
    mapper_thread_args_t *args = (mapper_thread_args_t *)arg;
    map_queue_t *queue = args->queue;
    mr_t mr = args->mr;
    mtx_t *write_mutex = args->mutex;
    mr_stats_t *stats = args->stats;

    //msg di avvio su log
    mr_log_write("[MAP]", m_work_tid_str, "SUCCESS", "Avvio di un thread worker");

    //dichiarazione file_line eventualmente da estrarre
    mr_file_line_t *l = NULL;

    while(1){

        //estrazione dalla mapper_queue
        l = map_queue_pop(queue);

        if(l == NULL) break;    //pop restituiscee NULL vuol dire che la coda è chiusa e vuota -> segnale di terminazione

        /*passaggio alla funzione mapper definita dall'utente con check (in caso di errore non mi aspetto che l'utente abbia implementato i check
        tipici del framework, di conseguenza l'errore viene trasmesso qui e non al livello inferiore (niente check silent)*/
        int res_map = mr->mapper(l, emit_pair, args, mr->user_arg);
        CHECK_GOTO_LOG(res_map == -1, ERR_GENER, "[MAP]", "mapper_worker_main", "Errore generico nella mapper", NULL, handle_fail, m_work_tid_str, 
            "Fallimento nella funzione mapper");
        
        //deallocazione della riga processata (allocata dal reader)
        free((void*)l->file_name);
        free((void*)l->line);
        free(l);
    }

    return 0;   //invio dati da parte del thread avvenuto correttamente

    //branch di terminazione in caso di errori
    handle_fail:
        //deallocazione della riga processata (allocata dal main)
        free((void*)l->file_name);
        free((void*)l->line);
        free(l);

        //chiusura della mapper_queue
        map_queue_close(queue);

        return -1;  //fallimento nell'invio dati da parte del thread
}


void mapper_process_main(mr_t mr){

    //creazione della stringa PID per il log per il mapper
    char map_pid_str[32];
    snprintf(map_pid_str, sizeof(map_pid_str), "P:%d", (int)getpid());
    
    //flag per i fallimenti
    int flag_write_mutex_init = 0;  //variabile per la deallocazione della mutex in caso di errore
    int flag_reader = 0;            //per capire se vada atteso o meno nella handle_fail
    int workers_to_join = 0;        //count per sapere quanti ne vanno attesi in caso di fail 
    int next_to_join = 0;           //indice per sapere il prossimo su cui far la join in caso di fail
    int reader_res = 0;             //per catturare l'errore del reader
    int worker_res = 0;             //per catturare l'errore del worker
    int workers_alloc = 0;          //per l'eventuale free dell'array
    int in_close = 0;               //per capire se è già stato chiuso o meno lo stdin (pulizia formale)
    int out_close = 0;              //per capire se è già stato chiuso o meno lo stdout (pulizia formale)
    
    //inizializzazione della mapper_queue con check
    map_queue_t queue;
    int res_mqi = map_queue_init(&queue, (int)mr->attr.queue_size, map_pid_str);
    CHECK_EXIT_SILENT(res_mqi == -1); //viene stampato il messaggio di errore registrato dalla funzione chiamata

    //variabile di mutex da passare ai worker per la corretta sincronizzazione delle scritture in output sulla pipe
    mtx_t write_mutex;

    //inizializzazione mutex con check e aggiornamento del flag in caso di success
    CHECK_GOTO_LOG(mtx_init(&write_mutex, mtx_plain) != thrd_success, ERR_SYNC_INIT, "[MAP]", "mapper_process_main", "write_mutex [mtx]", NULL, 
        handle_fail, map_pid_str, "Fallimento nell'inizializzazione della write_mutex [mtx] per la scrittura sincronizzata sulla pipe M-R");
    flag_write_mutex_init = 1;

    //inizializzazione struttura stats
    mr_stats_t m_stats;
    m_stats.lines_read = 0;
    m_stats.pairs_prod = 0;
    m_stats.distinct_tok = 0;
    m_stats.res_prod = 0;

    //inizializzazione struttura args da passare aI thread 
    mapper_thread_args_t args;
    args.queue = &queue;
    args.mr = mr;
    args.mutex = &write_mutex;
    args.stats = &m_stats; 

    //creazione dei thread worker, ossia i consumatori che prendono i dati dalla mapper queue, producono le coppie e le inviano al reducer
    int n_worker = (int)mr->attr.mapper_threads;    

    thrd_t *workers = malloc(n_worker * sizeof(thrd_t));
    CHECK_GOTO_LOG(workers == NULL, ERR_ALLOC, "[MAP]", "mapper_process_main", "workers", NULL, handle_fail, map_pid_str,
        "Fallimento allocazione memoria per l'array workers");                 
    workers_alloc = 1;
    
    for(int i = 0; i < n_worker ; i++){
        CHECK_GOTO_LOG(thrd_create(&workers[i], mapper_worker_main, &args) != thrd_success, ERR_SYSCALL, "[MAP]", "mapper_process_main", 
            "Create di un thread worker", NULL, handle_fail, map_pid_str, "Fallimento nella create di un thread worker");
        workers_to_join++;
    }

    //creazione del thread lettore dalla pipe, ossia il produttore che inserisce dati sulla mapper_queue
    thrd_t reader;
    CHECK_GOTO_LOG(thrd_create(&reader, mapper_reader_main, &args) != thrd_success, ERR_SYSCALL, "[MAP]", "mapper_process_main", 
        "Create del thread lettore dalla pipe", NULL, handle_fail, map_pid_str, "Fallimento nella create del thread lettore dalla pipe");
    
    flag_reader = 1; 

    //attesa del completamento della lettura dalla pipe P-M (scrittura sulla mapper_queue) con check
    thrd_join(reader, &reader_res);
    flag_reader = 0;
    CHECK_GOTO_SILENT(reader_res != 0, handle_fail); //riporta l'errore catturato nella funzione reader


    //termine della lettura
    mr_log_write("[MAP]", map_pid_str, "SUCCESS", "Terminazione lettura dati ricevuti dal principal");
    close(0);
    in_close = 1;

    //attesa del completamento della scrittura sulla pipe M-R (lettura sulla mapper-queue) con check
    for(int i = 0; i < n_worker ; i++){
        thrd_join(workers[i], &worker_res);
        next_to_join++;
        CHECK_GOTO_SILENT(worker_res != 0, handle_fail); //riporta l'errore catturato nella funzione worker
    }

    //termine della scrittura
    mr_log_write("[MAP]", map_pid_str, "SUCCESS", "Terminazione scrittura dati verso il reducer");
    close(1);
    out_close = 1;

    //scrittura dello stats file temporaneo del mapper
    write_stats_tmp("[MAP]", map_pid_str, &m_stats);

    //msg sul log del numero di righe lette e coppie prodotte
    char end_line[256];
    snprintf(end_line, sizeof(end_line), "Terminazione processo mapper. Righe lette (pipe P-M): %zu, Coppie prodotte, %zu", m_stats.lines_read, 
        m_stats.pairs_prod);

    mr_log_write("[MAP]", map_pid_str, "SUCCESS", end_line);

    //liberazione array
    free(workers);
    workers_alloc = 0;

    //distruzione mutex
    mtx_destroy(&write_mutex);

    //distruzione coda
    map_queue_destroy(&queue);

    _exit(0);   //processo mapper terminato correttamente

    //branch di terminazione in caso di errori
    handle_fail:
        //join dei thread rimasti sospesi
        if(flag_reader == 1){
            thrd_join(reader, NULL);
        }
        for(int i = next_to_join; i < workers_to_join; i++){
            thrd_join(workers[i], NULL);
        }

        //liberazione array
        if(workers_alloc == 1){
            free(workers);
        }

        //distruzione mutex
        if(flag_write_mutex_init == 1){
            mtx_destroy(&write_mutex);
        }

        //distruzione coda
        map_queue_destroy(&queue);

        //chiusura stdin
        if(in_close == 0){
            close(0);
        }

        //chiusura stdout
        if(out_close == 0){
            close(1);
        }

        _exit(1);   //errore nel processo mapper
}