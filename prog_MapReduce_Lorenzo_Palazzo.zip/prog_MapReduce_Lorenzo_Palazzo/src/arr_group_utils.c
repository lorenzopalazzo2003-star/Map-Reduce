//file c contenente la logica del processo reducer

//dichiarazione header e librerie
#include "arr_group_utils.h"
#include "checks.h"
#include <stdlib.h>
#include <string.h>

int gr_init(group_t *group, char *token, size_t token_len, const char *id_log){

    //inizializzazione campi semplici
    group->token =  token;          //assegnamento del token al campo corrispondente
    group->token_len = token_len;   //assegnamento della token_len al campo corrispondente
    group->size = 0;                //array inizialmente vuoto 
    group->capacity = 20;           /*valore arbitrario modificabile in base alla frequenza del token in questione (più volte il token appare, più
                                    conviene aumentarlo)*/

    //allocazione array
    group->values = (mr_value_t*)malloc(group->capacity*sizeof(mr_value_t));
    CHECK_RETURN_LOG(group->values == NULL, ERR_ALLOC, "[RED]", "gr_init", "values_array", NULL, id_log, 
        "Fallimento nell'allocazione della memoria per l'array di valori");
    
    return 0;   //inizializzazione avvenuta correttamente
}

int gr_add_value(group_t *group, mr_value_t *value, const char *id_log){

    if(group->size == group->capacity){   //non c'è più spazio nell'array
        int new_cap = group->capacity * 2; //capacità ipotetica futura (se realloc funziona) raddoppiata

        //allocazione di un'area di memoria raddoppiata per l'array con check
        mr_value_t* new_arr = (mr_value_t*) realloc (group->values, sizeof(mr_value_t) * new_cap);
        CHECK_RETURN_LOG(new_arr == NULL, ERR_ALLOC, "[RED]", "gr_add_value", "values_array", NULL, id_log, 
        "Fallimento nella riallocazione della memoria per l'add nell'array values");

        //realloc andata a buon fine
        group->capacity = new_cap;
        group->values = new_arr;
    }

    //c'è spazio nell'array (già c'era oppure è stato riallocato)

    //inserimento e incremento dell'indice
    group->values[group->size] = *value;
    group->size++;

    return 0;   //inserimento andato a buon fine
}

void gr_destroy(group_t *group){
    //free del token che è una copia allocata dal reader
    free(group->token);
    //free del campo values.data, che è una copia allocata dal reader
    for(int i = 0; i < group->size; i++){
        free((void*)group->values[i].data);
    }
    //free dell'array values
    if(group->values != NULL){
        free(group->values);
    }
    
    //update dei campi
    group->token = NULL;
    group->token_len = 0;
    group->values = NULL;
    group->size = 0;
    group->capacity = 0;
}

int gr_arr_init(group_array_t* gr_arr, const char* id_log){
    
    //inizializzazione campi semplici
    gr_arr->size = 0;           //array inizialmente vuoto        
    gr_arr->capacity = 200;     /*valore arbitrario modificabile in base alla granularità dei token (più token diversi si riscontrano, più conviene 
                                aumentarlo)*/
    
    //allocazione array
    gr_arr->groups = (group_t*)malloc(gr_arr->capacity*sizeof(group_t));
    CHECK_RETURN_LOG(gr_arr->groups == NULL, ERR_ALLOC, "[RED]", "gr_arr_init", "groups_array", NULL, id_log, 
        "Fallimento nell'allocazione della memoria per l'array di gruppi"); 

    return 0;   //inizializzazione avvenuta correttamente
}

int gr_arr_insert(group_array_t* gr_arr, group_t* group, const char* id_log){
    
    if(gr_arr->size == gr_arr->capacity){   //non c'è più spazio nell'array
        int new_cap = gr_arr->capacity * 2; //capacità ipotetica futura (se realloc funziona) raddoppiata

        //allocazione di un'area di memoria raddoppiata per l'array con check
        group_t* new_arr = (group_t*) realloc (gr_arr->groups, sizeof(group_t) * new_cap);
        CHECK_RETURN_LOG(new_arr == NULL, ERR_ALLOC, "[RED]", "gr_arr_insert", "groups_array", NULL, id_log, 
        "Fallimento nella riallocazione della memoria per l'insert nell'array groups");

        //realloc andata a buon fine
        gr_arr->capacity = new_cap;
        gr_arr->groups = new_arr;
    }

    //c'è spazio nell'array (già c'era oppure è stato riallocato)

    //inserimento e incremento dell'indice
    gr_arr->groups[gr_arr->size] = *group;
    gr_arr->size++;

    return 0;   //inserimento andato a buon fine
}

int gr_arr_find(group_array_t* gr_arr, const char *token){

    //ciclo di ricerca lineare
    for(int i = 0; i < gr_arr->size; i++){
        if(strcmp(gr_arr->groups[i].token, token) == 0){
            return i;   //ricerca ha avuto successo, ritorna l'indice del gruppo
        }
    }

    return -1;  //ricerca non ha avuto successo
}

//funzione d'appoggio per il quicksort
static int compare_groups(const void* gr1, const void* gr2){
    const group_t* group1 = (const group_t*)gr1;
    const group_t* group2 = (const group_t*)gr2;
    return strcmp(group1->token, group2->token);
}

void gr_arr_sort(group_array_t* gr_arr){
    
    if(gr_arr->size > 1){    //se ci sono almeno 2 elementi fai l'ordinamento
        qsort(gr_arr->groups, gr_arr->size, sizeof(group_t), compare_groups);
    }

    return;   //ordinamento completato correttamente
}

void gr_arr_destroy(group_array_t* gr_arr){

    if(gr_arr->groups != NULL){
        for(int i = 0; i < gr_arr->size; i++){ //liberazione della memoria allocata interna ad ogni gruppo
            gr_destroy(&gr_arr->groups[i]);
        }
        //liberazione dell'array di gruppi
        free(gr_arr->groups);
    }

    //reset dei campi
    gr_arr->groups = NULL;
    gr_arr->size = 0;
    gr_arr->capacity = 0;
}