//file header per la gestione del file di log

#ifndef LOGGER_H
#define LOGGER_H

//funzione per aprire il file di log 
int mr_log_init(const char* path);

//funzione per scrivere sul file di log 
void mr_log_write(const char* pre, const char* thr, const char* even, const char* msg);

//funzione per chiudere il file di log
int mr_log_destroy(void);

#endif