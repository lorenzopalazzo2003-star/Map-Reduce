//file header per la scrittura del filee contenente le statische globali richiesto dall'addendum

#ifndef STATS_WRITER_H
#define STATS_WRITER_H

//dichiarazione header e librerie
#include "../include/mr.h"

//struttura necessaria per contenere le statistiche globali
typedef struct {
    size_t lines_read;       //righe lette   
    size_t pairs_prod;       //coppie (token, valore) prodotte
    size_t distinct_tok;     //token unici elaborati
    size_t res_prod;         //risultati finali scritti in output
} mr_stats_t;

//funzione che ritorna il tempo corrente, calcolato al volo al momento della terminazione del processo, al fine di calcolare il tempo di exec
double get_current_time_double(void);

//funzione che ritorna un file temporaneo delle statistiche di un processo 
int write_stats_tmp(const char *pre, const char *id_log, const mr_stats_t *stats);

//funzione che scrive il file delle statistiche e cancella i temporanei
int write_stats_file(const char *output_path, double time);

#endif