#!/bin/bash

SUCCESS=0
FAIL=0

EXEC=./ex_count_occur
TEST_DIR=tests
INPUT_DIR=$TEST_DIR/input
EXP_OUT_DIR=$TEST_DIR/exp_output
TMP1=/tmp/out_test1.bin
TMP2=/tmp/out_test2.bin
TMP3=/tmp/out_test3.bin
TMP4=/tmp/out_test4.bin
TMP5=/tmp/out_test5.bin

echo "AVVIO TEST"

echo "----------------------------"
echo "Test 1: exec su file normale"

$EXEC $INPUT_DIR/input_test1.txt $TMP1

if [ $? != 0 ]; then
    echo "FAIL: Valore di uscita != 0"
    FAIL=$((FAIL + 1))
else
    if [ ! -s $TMP1 ]; then
        echo "FAIL: File di output vuoto"
        FAIL=$((FAIL + 1))
    else 
        echo "SUCCESS: File di output valido"
        SUCCESS=$((SUCCESS + 1))
    fi
fi

echo "--------------------------"
echo "Test 2: exec su file vuoto"

$EXEC $INPUT_DIR/input_test2.txt $TMP2

if [ $? != 0 ]; then
    echo "FAIL: Valore di uscita != 0"
    FAIL=$((FAIL + 1))
else
    if [ -s $TMP2 ]; then
        echo "FAIL: File di output non vuoto"
        FAIL=$((FAIL + 1))
    else 
        echo "SUCCESS: File di output valido"
        SUCCESS=$((SUCCESS + 1))
    fi
fi

echo "--------------------------"
echo "Test 3: exec su directory"

$EXEC $INPUT_DIR/input_dir $TMP3

if [ $? != 0 ]; then
    echo "FAIL: Valore di uscita != 0"
    FAIL=$((FAIL + 1))
else
    if [ ! -s $TMP3 ]; then
        echo "FAIL: File di output vuoto"
        FAIL=$((FAIL + 1))
    else 
        echo "SUCCESS: File di output valido"
        SUCCESS=$((SUCCESS + 1))
    fi
fi

echo "------------------------------------------"
echo "Test 4: 2 exec consecutive su input uguali"

$EXEC $INPUT_DIR/input_test1.txt $TMP1
$EXEC $INPUT_DIR/input_test1.txt $TMP4

if [ $? != 0 ]; then
    echo "FAIL: Valure di uscita != 0"
    FAIL=$((FAIL + 1))
else
    if ! diff -q $TMP1 $TMP4; then
        echo "FAIL: Output non deterministico"
        FAIL=$((FAIL + 1))
    else 
        echo "SUCCESS: File di output valido"
        SUCCESS=$((SUCCESS + 1))
    fi
fi

echo "-----------------------------------"
echo "Test 5: File contenente righe vuote"
$EXEC $INPUT_DIR/input_test5.txt $TMP5

if [ $? != 0 ]; then
    echo "FAIL: Valore di uscita != 0"
    FAIL=$((FAIL + 1))
else
    if [ ! -s $TMP5 ]; then
        echo "FAIL: File di output vuoto"
        FAIL=$((FAIL + 1))
    else 
        echo "SUCCESS: File di output valido"
        SUCCESS=$((SUCCESS + 1))
    fi
fi

rm -f $TMP1 $TMP2 $TMP3 $TMP4 $TMP5

echo "---------------"
echo "Test terminati!"

echo "Fail: $FAIL su 5"
echo "Success: $SUCCESS su 5"

if [ $FAIL != 0 ]; then
    echo "Sono occorsi dei Fallimenti"
    exit 1
else
    echo "Test ha avuto successo"
    exit 0
fi

