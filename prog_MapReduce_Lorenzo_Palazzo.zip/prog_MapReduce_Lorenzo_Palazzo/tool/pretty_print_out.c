//programma ausiliario per la stampa in modo leggibile del file di output
//disclaimer: il programma funziona solo con output per cui il tipo di result sia un int (come nell'esempio ex_count_occur)

//dichiarazione header e librerie
#include <stdlib.h>
#include <stdio.h>

//funzione main
int main(int argc, char **argv){
    
    if(argc != 2){
        fprintf(stderr, "Errore: deve essere passati 1 argomento: <file di output>\n");
        return -1;
    }

    //apertura del file di output il modalità di lettura binaria
    FILE *f = fopen(argv[1], "rb");

    //check sull'apertura
    if(f == NULL){
        perror("Errore nell'apertura del file di output");
        return -1;
    }

    //ciclo di lettura del file binario: termina a EOF
    while(1){

        //1o dato letto: token_len

        int token_len = 0;
        size_t res_tl = fread(&token_len, sizeof(int), 1, f);

        //check se è 0: EOF-> fine del ciclo di lettura
        if(res_tl == 0){
            break;
        }
        //check su lettura di token len: non può esser < 0 nè maggiore di MAX_TOKEN_LEN(2048)
        if(res_tl != 1 || token_len <= 0 || token_len > 2048){
            fprintf(stderr, "Errore lettura token_len\n");
            fclose(f);
            return -1;
        }

        //2o dato letto token

        //allocazione memoria
        char* token = malloc(token_len + 1);

        //check su allocazione e lettura
        if(token == NULL || fread(token, token_len, 1, f) != 1){
            fprintf(stderr, "Errore lettura token\n");
            free(token);
            fclose(f);
            return -1;
        }

        //aggiunta del terminatore per elaborare il token come stringa
        token[token_len] = '\0';

        //3o dato letto: result_size

        int result_size = 0;
        size_t res_rs = fread(&result_size, sizeof(int), 1, f);

        //check su risultato della read (nessun check sulla dim perchè si svolge dopo al momento della lettura del result)
        if(res_rs != 1){
            fprintf(stderr, "Errore lettura result_size\n");
            free(token);
            fclose(f);
            return -1;
        }

        //4o dato letto: result
        if(result_size == sizeof(int)){
            int result = 0;
            int res_res = fread(&result, result_size, 1, f);

            //check su risultato della read
            if(res_res != 1){
                fprintf(stderr, "Errore lettura result\n");
                free(token);
                fclose(f);
                return -1;
            }

            printf("Token [%s]: Result [%d] \n", token, result);
        }
        else{
            printf("Result non è un int");
            return -1;
        }
    }

    return 0;
}